import * as i0 from "@angular/core";
import { TemplateRef } from "@angular/core";
/**
 * Öffnet ein Popup-Element (Dropdown-Menü, Kalender, Autocomplete-Menü) nach oben statt nach
 * unten, wenn unterhalb des Ankers nicht genug Platz ist. Portiert aus widgets-spaceship/demo.js,
 * §14 der Spezifikation ("Geteilte Primitives").
 */
export declare function flipIfNeeded(anchorEl: HTMLElement, popupEl: HTMLElement, upClass: string, gap: number): void;
/**
 * Konfiguration für {@link registerDismissibleOverlay}.
 */
export interface DismissibleOverlayOptions {
  /** Ob das Overlay aktuell geöffnet ist (die Listener sind sonst No-ops). */
  isOpen: () => boolean;
  /** Wird aufgerufen, wenn das Overlay geschlossen werden soll. */
  close: () => void;
  /** Liefert true, wenn `target` Teil des Overlays (Trigger und/oder Panel) ist. */
  isInside: (target: Node) => boolean;
  /**
   * Ob ein Klick außerhalb des Overlays schließt. Standard true — der Wizard (§18 der
   * Spezifikation) setzt dies bewusst auf false, um versehentlichen Datenverlust bei
   * Formulareingaben zu vermeiden; Escape schließt dort trotzdem.
   */
  closeOnOutsideClick?: boolean;
}
/**
 * Registriert dokumentweite `click`- und `Escape`-`keydown`-Listener für ein Overlay-Widget
 * (Modal, Popover, Dropdown, Datepicker, Autocomplete, Wizard) und räumt sie beim Zerstören der
 * Component über `DestroyRef` automatisch auf.
 *
 * In der Vanilla-Referenzbibliothek (widgets-spaceship/demo.js) ist genau dieser Cleanup laut
 * Spezifikation ("Offene Entscheidungen für Angular/Svelte") bewusst ungelöst — hier ist er
 * Pflicht. Muss in einem Injection-Context aufgerufen werden (z. B. im Constructor/Field-
 * Initializer einer Component).
 */
export declare function registerDismissibleOverlay(options: DismissibleOverlayOptions): void;
/** Seite des Ankers, auf der das Popup liegt. */
export type AnchoredPopupSide = 'below' | 'above';
/**
 * Horizontale Ausrichtung am Anker: `start`/`end` sind logisch (in RTL gespiegelt), `center`
 * mittig über dem Anker.
 */
export type AnchoredPopupAlign = 'start' | 'center' | 'end';
/**
 * Konfiguration für {@link registerAnchoredPopup}.
 */
export interface AnchoredPopupOptions {
  /** Element, an dem das Popup ausgerichtet wird (z. B. Eingabefeld oder Trigger-Button). */
  anchor: () => HTMLElement | undefined;
  /** Das Popup mit `popover="manual"`; `undefined`, solange es geschlossen ist. */
  popup: () => HTMLElement | undefined;
  /** Abstand zwischen Anker und Popup in px. */
  gap: number;
  /** Bevorzugte Seite, Standard `below`; als Funktion, wenn sie von einem Input abhängt. */
  side?: AnchoredPopupSide | (() => AnchoredPopupSide);
  /**
   * Auf die andere Seite wechseln, wenn das Popup auf der bevorzugten nicht passt und dort mehr
   * Platz ist (Regel wie `flipIfNeeded`). Standard true; das Popover (§14) wechselt bewusst nicht.
   */
  flip?: boolean;
  /** Modifier-Klasse, solange das Popup über dem Anker liegt (z. B. `rs-calendar--up`). */
  upClass?: string;
  /** Standard `start`; als Funktion, wenn sie vom Kontext abhängt (z. B. per CSS-Variable). */
  align?: AnchoredPopupAlign | (() => AnchoredPopupAlign);
  /** Popup so breit wie der Anker (Dropdown-Menü), sonst behält es seine CSS-Breite. */
  matchWidth?: boolean;
}
/**
 * Zeigt ein Popup mit `popover="manual"` in der Top-Layer und richtet es mit `position: fixed`
 * an seinem Anker aus. In der Top-Layer schneidet kein Vorfahr mit `overflow` das Popup ab (z. B.
 * `.rs-table__scroll`, eine Tabellenzelle, `.rs-wizard__content` oder ein scrollendes Modal), und
 * kein Stacking Context liegt darüber. Passt es auf keiner Seite, wird es in den Viewport
 * geschoben und überdeckt den Anker; seitlich bleibt es immer im Viewport. Erweiterung gegenüber
 * §13–§19 der Spezifikation (dort `position: absolute` am Anker).
 *
 * Weil das Popup im Viewport fixiert ist, richtet es sich beim Scrollen (auch in Containern,
 * daher capture), bei Größenänderung des Fensters und des Ankers (z. B. Chips im Multiselect)
 * neu aus; die Listener räumt `DestroyRef` auf. Muss in einem Injection-Context aufgerufen werden.
 *
 * @returns `place()` für den `afterRenderEffect` des Widgets: zeigt das geöffnete Popup und
 *   richtet es aus. Erst danach fokussieren, ein verborgenes Popover nimmt keinen Fokus an.
 */
export declare function registerAnchoredPopup(options: AnchoredPopupOptions): () => void;
export type RsToggleStatus = 'green' | 'yellow' | 'red';
/**
 * Slide-Toggle, §3 der widgets-spaceship-Spezifikation. Der Zustand lebt vollständig im
 * `aria-checked`-Attribut (Vertrag der Vanilla-Bibliothek) — in Angular als zwei-Wege-`model()`
 * abgebildet, sodass Consumer sowohl `[(checked)]` als auch `[checked]`/`(checkedChange)`
 * verwenden können.
 */
export declare class RsToggle {
  readonly checked: import("@angular/core").ModelSignal<boolean>;
  readonly status: import("@angular/core").InputSignal<RsToggleStatus>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  protected toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsToggle, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsToggle, "rs-toggle", never, {
    "checked": {
      "alias": "checked";
      "required": false;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
  }, {
    "checked": "checkedChange";
  }, never, never, true, never>;
}
export declare class RsAccordionItem {
  private readonly accordion;
  readonly header: import("@angular/core").InputSignal<string>;
  protected get expanded(): boolean;
  protected toggle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsAccordionItem, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsAccordionItem, "rs-accordion-item", never, {
    "header": {
      "alias": "header";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
/**
 * Accordion-Container, §11 der widgets-spaceship-Spezifikation: nur ein `RsAccordionItem`
 * gleichzeitig geöffnet. Klick auf einen bereits offenen Trigger schließt ihn wieder (kein Panel
 * offen ist ein gültiger Zustand).
 */
export declare class RsAccordion {
  private readonly openItem;
  isOpen(item: RsAccordionItem): boolean;
  toggle(item: RsAccordionItem): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsAccordion, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsAccordion, "rs-accordion", never, {}, {}, never, ["*"], true, never>;
}
/**
 * Tabs-Leiste, §8 der widgets-spaceship-Spezifikation. Reine Navigationsleiste — Tab-Inhalte
 * (Panels) sind nicht Teil dieses Widgets und werden vom Consumer anhand von `activeIndex`
 * selbst gerendert.
 */
export declare class RsTabs {
  readonly items: import("@angular/core").InputSignal<readonly string[]>;
  readonly activeIndex: import("@angular/core").ModelSignal<number>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsTabs, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsTabs, "rs-tabs", never, {
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
    "activeIndex": {
      "alias": "activeIndex";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeIndex": "activeIndexChange";
  }, never, never, true, never>;
}
/**
 * Sidebar-Navigation, §8 der widgets-spaceship-Spezifikation. Gleiches Verhalten wie `RsTabs`
 * (aktive Klasse per Klick umschalten), nur vertikales Markup (`<nav>` statt `<div>`).
 */
export declare class RsSidenav {
  readonly items: import("@angular/core").InputSignal<readonly string[]>;
  readonly activeIndex: import("@angular/core").ModelSignal<number>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsSidenav, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsSidenav, "rs-sidenav", never, {
    "items": {
      "alias": "items";
      "required": true;
      "isSignal": true;
    };
    "activeIndex": {
      "alias": "activeIndex";
      "required": false;
      "isSignal": true;
    };
  }, {
    "activeIndex": "activeIndexChange";
  }, never, never, true, never>;
}
export type RsGaugeVariant = 'round' | 'bar';
export type RsGaugeStatus = 'ok' | 'warn' | 'crit';
/** Kreisumfang bei r=50 (2πr), §5 der Spezifikation. */
export declare const RS_GAUGE_ROUND_CIRCUMFERENCE = 314.16;
/**
 * Gauge (rund/Balken), §5 der widgets-spaceship-Spezifikation. Der runde Gauge bekommt einen
 * einmaligen Ladeeffekt (leer → Zielwert) — erst nach dem ersten tatsächlichen Rendern
 * (`afterNextRender`) wird der Zielwert gesetzt, damit der CSS-`transition` auf
 * `stroke-dashoffset` sichtbar abläuft. Der Balken-Gauge braucht das nicht (reines CSS, siehe
 * Spec) und bindet `--rs-gauge-pct` direkt.
 */
export declare class RsGauge {
  readonly variant: import("@angular/core").InputSignal<RsGaugeVariant>;
  readonly value: import("@angular/core").InputSignal<number>;
  readonly status: import("@angular/core").InputSignal<RsGaugeStatus>;
  readonly label: import("@angular/core").InputSignal<string>;
  protected readonly circumference = 314.16;
  protected readonly renderedOffset: import("@angular/core").WritableSignal<number>;
  private mounted;
  constructor();
  private targetOffset;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsGauge, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsGauge, "rs-gauge", never, {
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": true;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type RsLogSeverity = 'info' | 'warn' | 'crit';
export interface RsLogEntry {
  time: string;
  message: string;
  severity?: RsLogSeverity;
}
/**
 * Log-Panel, §6 der widgets-spaceship-Spezifikation. Autoscroll bei jedem neuen Eintrag
 * (`scrollTop = scrollHeight`), umgesetzt über `afterRenderEffect` — läuft garantiert nach dem
 * DOM-Update, im Gegensatz zu einem einfachen `effect()`.
 */
export declare class RsLogPanel {
  readonly entries: import("@angular/core").InputSignal<readonly RsLogEntry[]>;
  private readonly list;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<RsLogPanel, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsLogPanel, "rs-log-panel", never, {
    "entries": {
      "alias": "entries";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export type RsFieldStatus = 'default' | 'error' | 'warn';
/**
 * Passwort-Eingabefeld mit Sichtbarkeits-Toggle, §9 der widgets-spaceship-Spezifikation. Reine
 * Text-/Error-/Warn-Felder brauchen laut Spezifikation kein JS und bleiben CSS-only
 * (`.rs-field`/`.rs-input` direkt im Markup) — nur die Passwort-Variante braucht eine Component.
 */
export declare class RsPasswordField {
  readonly label: import("@angular/core").InputSignal<string>;
  readonly hint: import("@angular/core").InputSignal<string>;
  readonly status: import("@angular/core").InputSignal<RsFieldStatus>;
  readonly disabled: import("@angular/core").InputSignal<boolean>;
  readonly value: import("@angular/core").ModelSignal<string>;
  protected readonly visible: import("@angular/core").WritableSignal<boolean>;
  protected toggleVisibility(): void;
  protected onInput(event: Event): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsPasswordField, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsPasswordField, "rs-password-field", never, {
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
    "hint": {
      "alias": "hint";
      "required": false;
      "isSignal": true;
    };
    "status": {
      "alias": "status";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
  }, never, never, true, never>;
}
export type RsModalVariant = 'info' | 'confirm' | 'crit';
/**
 * Modal, §7 der widgets-spaceship-Spezifikation. Escape schließt global, Klick auf das Overlay
 * außerhalb des Panels schließt. Öffnen/Schließen bauen das Markup per `@if` komplett auf/ab
 * (statt `hidden` zu toggeln) — entspricht dem Vanilla-Vertrag "Overlay+Modal-Markup
 * einfügen"/"Inhalt leeren".
 */
export declare class RsModal {
  readonly open: import("@angular/core").ModelSignal<boolean>;
  readonly title: import("@angular/core").InputSignal<string>;
  readonly variant: import("@angular/core").InputSignal<RsModalVariant>;
  private readonly panel;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<RsModal, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsModal, "rs-modal", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "variant": {
      "alias": "variant";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, ["*"], true, never>;
}
/**
 * Popover-Panel, §14 der widgets-spaceship-Spezifikation. Der Trigger ist bewusst NICHT Teil
 * dieser Component (der Consumer bringt sein eigenes `<button class="rs-btn ...">` mit, siehe
 * spec-Markup `data-popover-trigger`) — er wird per `RsPopoverTrigger`-Direktive
 * (`[rsPopoverTrigger]="panelRef"`) angebunden. Klick-getriggert, Außenklick (weder Trigger noch
 * Panel) sowie Escape schließen. Feste Position (unterhalb, linksbündig) — die Spezifikation
 * nutzt hier bewusst KEINE `flipIfNeeded`-Logik (anders als Dropdown/Datepicker/Autocomplete).
 *
 * Erweiterung gegenüber §14: Das Panel ist ein Popover in der Top-Layer, am Trigger ausgerichtet
 * (`registerAnchoredPopup` ohne Richtungswechsel), damit es kein Container mit `overflow`
 * abschneidet. Die Ausrichtung am Ende statt am Anfang des Triggers kommt aus dem Kontext-CSS
 * (`--rs-popover-align: end`, z. B. in der App-Bar).
 */
export declare class RsPopover {
  readonly open: import("@angular/core").ModelSignal<boolean>;
  readonly title: import("@angular/core").InputSignal<string>;
  private readonly elementRef;
  private readonly panel;
  private triggerEl;
  constructor();
  registerTrigger(el: HTMLElement): void;
  toggle(): void;
  private contextAlign;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsPopover, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsPopover, "rs-popover", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, never, ["*"], true, never>;
}
/**
 * Bindet ein beliebiges, vom Consumer gestaltetes `<button>` als Trigger an ein
 * `RsPopover`-Panel: `<button [rsPopoverTrigger]="panelRef" ...>`, `<rs-popover #panelRef>`.
 */
export declare class RsPopoverTrigger {
  private readonly elementRef;
  readonly rsPopoverTrigger: import("@angular/core").InputSignal<RsPopover>;
  constructor();
  static ɵfac: i0.ɵɵFactoryDeclaration<RsPopoverTrigger, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<RsPopoverTrigger, "[rsPopoverTrigger]", never, {
    "rsPopoverTrigger": {
      "alias": "rsPopoverTrigger";
      "required": true;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
/**
 * Tooltip, §13 der widgets-spaceship-Spezifikation, mit unverändertem Markup
 * (`data-tooltip="Text"`, optional `data-tooltip-pos="bottom"`). Ohne diese Direktive zeigt
 * `widgets.css` den Text rein per CSS als `::after` — den schneidet jeder Vorfahr mit `overflow`
 * ab (z. B. eine Tabellenzelle), und am Viewport-Rand ragt er hinaus.
 *
 * Erweiterung gegenüber §13: Mit importierter Direktive erscheint der Text stattdessen als Popover
 * in der Top-Layer, mittig über bzw. unter dem Element, bei zu wenig Platz auf der anderen Seite
 * und seitlich im Viewport. Sichtbar wie bisher bei Hover und Tastaturfokus (`:focus-visible`);
 * Escape blendet ihn aus. Das Element hängt an `<body>` (die Theme-Klasse `rs-root--light`
 * gehört deshalb an `<body>`) und beschreibt den Host per `aria-describedby`.
 */
export declare class RsTooltip {
  /** Tooltip-Text, Attribut `data-tooltip` wie in §13. */
  readonly text: import("@angular/core").InputSignal<string>;
  /** `bottom` zeigt den Tooltip unter statt über dem Element (Attribut `data-tooltip-pos`). */
  readonly position: import("@angular/core").InputSignal<"top" | "bottom">;
  private readonly host;
  private readonly tooltipEl;
  private readonly hovered;
  protected readonly focusVisible: import("@angular/core").WritableSignal<boolean>;
  /** Escape blendet aus, bis der Zeiger oder der Fokus erneut auf das Element kommt. */
  protected readonly dismissed: import("@angular/core").WritableSignal<boolean>;
  private readonly visible;
  /** Eine vom Consumer gesetzte Beschreibung bleibt erhalten. */
  protected readonly describedBy: string;
  constructor();
  protected onHover(hovered: boolean): void;
  /** Wie `:focus-visible` im CSS-Tooltip: nur bei Tastaturfokus, nicht nach einem Klick. */
  protected onFocus(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsTooltip, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<RsTooltip, "[data-tooltip]", never, {
    "text": {
      "alias": "data-tooltip";
      "required": true;
      "isSignal": true;
    };
    "position": {
      "alias": "data-tooltip-pos";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, never, true, never>;
}
export interface RsDropdownOption {
  value: string;
  label: string;
}
/**
 * Dropdown (Single + Multiselect), §15 der widgets-spaceship-Spezifikation. Öffnungsrichtung via
 * `flipIfNeeded`, Außenklick/Escape schließen. Optionen werden per `@for` gefiltert (nicht
 * `[hidden]`) — sidestept die in der Spec dokumentierte `[hidden]`-vs-`display`-Kollision
 * strukturell. Erweiterung gegenüber §15: Das Menü ist ein Popover in der Top-Layer
 * (`registerAnchoredPopup`), damit ihn kein Container mit `overflow` abschneidet.
 */
export declare class RsDropdown {
  readonly options: import("@angular/core").InputSignal<readonly RsDropdownOption[]>;
  readonly multi: import("@angular/core").InputSignal<boolean>;
  readonly searchable: import("@angular/core").InputSignal<boolean>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  /** Ausgewählter Wert im Single-Modus. */
  readonly value: import("@angular/core").ModelSignal<string | null>;
  /** Ausgewählte Werte im Multi-Modus. */
  readonly values: import("@angular/core").ModelSignal<readonly string[]>;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  protected readonly query: import("@angular/core").WritableSignal<string>;
  /** Nach dem Öffnen eines durchsuchbaren Menüs das Suchfeld fokussieren. */
  private focusSearchPending;
  private readonly trigger;
  private readonly menu;
  private readonly searchInput;
  protected readonly filteredOptions: import("@angular/core").Signal<readonly RsDropdownOption[]>;
  protected readonly selectedChips: import("@angular/core").Signal<RsDropdownOption[]>;
  constructor();
  protected toggleOpen(): void;
  protected selectSingle(option: RsDropdownOption): void;
  protected toggleMulti(option: RsDropdownOption): void;
  protected removeChip(value: string, event: Event): void;
  protected onSearchInput(event: Event): void;
  protected isSelected(option: RsDropdownOption): boolean;
  protected triggerLabel(): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsDropdown, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsDropdown, "rs-dropdown", never, {
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "multi": {
      "alias": "multi";
      "required": false;
      "isSignal": true;
    };
    "searchable": {
      "alias": "searchable";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "values": {
      "alias": "values";
      "required": false;
      "isSignal": true;
    };
  }, {
    "value": "valueChange";
    "values": "valuesChange";
  }, never, never, true, never>;
}
/**
 * Datepicker / Datetimepicker, §16 der widgets-spaceship-Spezifikation. Selbst gebauter
 * Kalender, deutsche Monatsnamen, Montag als Wochenstart. `date`/`time` als `model()` ersetzen
 * den vanilla `onChange`-Callback — Consumer nutzt `[(date)]`/`(dateChange)` statt einer
 * Callback-Option.
 *
 * Erweiterungen gegenüber §16: erlaubter Zeitraum (`minDate`, `maxDate`), Tastatursteuerung im
 * Kalender (ein Tab-Stopp, Pfeiltasten, Rückkehr des Fokus), Nutzung mit Signal Forms
 * (`[formField]` über das zusätzliche Model `value`, dazu `disabled`, `invalid`, `touch`) und der
 * Kalender als Popover in der Top-Layer, damit ihn kein Container mit `overflow` abschneidet.
 */
export declare class RsDatepicker {
  readonly withTime: import("@angular/core").InputSignal<boolean>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  /**
   * Erweiterung gegenüber §16: frühester erlaubter Tag (die Uhrzeit zählt nicht). Bewusst nicht
   * `min`: Neben `[formField]` darf `[min]` nicht gebunden werden, und Signal Forms setzt `min` nur
   * für Zahlen.
   */
  readonly minDate: import("@angular/core").InputSignal<Date | null>;
  /** Erweiterung gegenüber §16: spätester erlaubter Tag, siehe `minDate`. */
  readonly maxDate: import("@angular/core").InputSignal<Date | null>;
  /** Erweiterung gegenüber §16: Eingabefeld und Kalender-Schaltfläche gesperrt. */
  readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /** Erweiterung gegenüber §16: Fehlerdarstellung wie `.rs-input` in `.rs-field--error`. */
  readonly invalid: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  readonly date: import("@angular/core").ModelSignal<Date | null>;
  /**
   * Erweiterung gegenüber §16: dasselbe Datum wie `date`, für `[formField]` (Signal Forms erwartet
   * ein Model namens `value`). Eine Auswahl schreibt beide Models.
   */
  readonly value: import("@angular/core").ModelSignal<Date | null>;
  readonly time: import("@angular/core").ModelSignal<string>;
  /** Erweiterung gegenüber §16: Der Fokus hat Eingabefeld und Kalender verlassen. */
  readonly touch: import("@angular/core").OutputEmitterRef<void>;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  protected readonly viewMonth: import("@angular/core").WritableSignal<Date>;
  /** Tag mit dem Fokus im Raster; nur er ist per Tab erreichbar (Roving Tabindex). */
  protected readonly activeDate: import("@angular/core").WritableSignal<Date>;
  protected readonly weekdayLabels: string[];
  private readonly elementRef;
  private readonly calendar;
  private readonly inputEl;
  /** Element, das den Kalender geöffnet hat; bekommt den Fokus beim Schließen zurück. */
  private trigger;
  /** Jede Erhöhung fokussiert nach dem nächsten Rendern den Tag mit `tabindex="0"`. */
  private readonly focusRequest;
  private handledFocusRequest;
  /** Angezeigtes Datum: das zuletzt geänderte der beiden Models `date` und `value`. */
  protected readonly selected: import("@angular/core").WritableSignal<Date | null>;
  private readonly min;
  private readonly max;
  protected readonly canPrev: import("@angular/core").Signal<boolean>;
  protected readonly canNext: import("@angular/core").Signal<boolean>;
  protected readonly title: import("@angular/core").Signal<string>;
  protected readonly leadingBlanks: import("@angular/core").Signal<number>;
  protected readonly blanks: import("@angular/core").Signal<unknown[]>;
  protected readonly dayNumbers: import("@angular/core").Signal<number[]>;
  /**
   * Tag mit `tabindex="0"`: der aktive Tag, wenn er im angezeigten Monat liegt, sonst der erste
   * erlaubte Tag des Monats (z. B. nach ‹ oder ›).
   */
  protected readonly tabStopDay: import("@angular/core").Signal<number | null>;
  protected readonly formattedValue: import("@angular/core").Signal<string>;
  constructor();
  /** Setzt den ausgewählten Wert zurück (Vanilla-Vertrag: `{ clear }`-Rückgabe von `initDatepicker`). */
  clear(): void;
  protected toggleOpen(trigger: HTMLElement): void;
  /** Enter, Leertaste und Pfeil runter öffnen den Kalender bzw. führen in das Raster. */
  protected onInputKeydown(event: KeyboardEvent): void;
  /** Escape schließt nur den Kalender (nicht z. B. ein umgebendes Modal) und gibt den Fokus zurück. */
  protected onEscape(event: Event): void;
  /** Verlässt der Fokus das Widget, schließt der Kalender, und `touch` wird ausgelöst. */
  protected onFocusOut(event: FocusEvent): void;
  protected onGridKeydown(event: KeyboardEvent): void;
  protected onDayFocus(day: number): void;
  protected prevMonth(): void;
  protected nextMonth(): void;
  protected selectDay(day: number): void;
  protected onTimeChange(event: Event): void;
  protected isToday(day: number): boolean;
  protected isSelected(day: number): boolean;
  protected isAllowedDay(day: number): boolean;
  /** Öffnet auf dem ausgewählten Tag, sonst auf heute, jeweils in den erlaubten Zeitraum geschoben. */
  private openCalendar;
  /** Fokus zuerst zurückgeben, sonst landet er mit dem entfernten Tag auf `<body>`. */
  private close;
  private isAllowed;
  private clamp;
  private dateFor;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsDatepicker, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsDatepicker, "rs-datepicker", never, {
    "withTime": {
      "alias": "withTime";
      "required": false;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "minDate": {
      "alias": "minDate";
      "required": false;
      "isSignal": true;
    };
    "maxDate": {
      "alias": "maxDate";
      "required": false;
      "isSignal": true;
    };
    "disabled": {
      "alias": "disabled";
      "required": false;
      "isSignal": true;
    };
    "invalid": {
      "alias": "invalid";
      "required": false;
      "isSignal": true;
    };
    "date": {
      "alias": "date";
      "required": false;
      "isSignal": true;
    };
    "value": {
      "alias": "value";
      "required": false;
      "isSignal": true;
    };
    "time": {
      "alias": "time";
      "required": false;
      "isSignal": true;
    };
  }, {
    "date": "dateChange";
    "value": "valueChange";
    "time": "timeChange";
    "touch": "touch";
  }, never, never, true, never>;
}
/**
 * Entfernbare Liste, §20 der widgets-spaceship-Spezifikation. `add()` entspricht der
 * `{ add }`-Rückgabe von `initList` (Erweiterungspunkt für `RsAutocomplete`, §19) — der übliche
 * Angular-Weg ist aber, `values` direkt als `model()` zu binden, z. B.
 * `(commit)="crewList.update(v => [...v, $event])"` vom Autocomplete aus.
 */
export declare class RsList {
  readonly values: import("@angular/core").ModelSignal<readonly string[]>;
  readonly emptyLabel: import("@angular/core").InputSignal<string>;
  add(value: string): void;
  protected removeAt(index: number): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsList, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsList, "rs-list", never, {
    "values": {
      "alias": "values";
      "required": false;
      "isSignal": true;
    };
    "emptyLabel": {
      "alias": "emptyLabel";
      "required": false;
      "isSignal": true;
    };
  }, {
    "values": "valuesChange";
  }, never, never, true, never>;
}
export interface RsAutocompleteHighlight {
  before: string;
  match: string;
  after: string;
}
/**
 * Autocomplete-Input, §19 der widgets-spaceship-Spezifikation. Freitext bleibt immer gültig
 * (die Vorschlagsliste ist nur eine Eingabehilfe) — `commit` feuert sowohl bei Vorschlags-Auswahl
 * als auch bei akzeptiertem Freitext; der Consumer verbindet das üblicherweise mit einer
 * `RsList` (§20), z. B. `(commit)="crewList.update(v => [...v, $event])"`. Das Hervorheben des
 * Treffers nutzt Angulars Text-Interpolation (kein `innerHTML`) — dadurch ist kein Roh-HTML aus
 * der Nutzereingabe übernehmbar, das XSS-Anliegen der Spezifikation ist damit konstruktionsbedingt
 * erfüllt. Erweiterung gegenüber §19: Die Vorschlagsliste ist ein Popover in der Top-Layer
 * (`registerAnchoredPopup`), damit sie kein Container mit `overflow` abschneidet.
 */
export declare class RsAutocomplete {
  readonly options: import("@angular/core").InputSignal<readonly string[]>;
  readonly placeholder: import("@angular/core").InputSignal<string>;
  readonly query: import("@angular/core").ModelSignal<string>;
  readonly commit: import("@angular/core").OutputEmitterRef<string>;
  protected readonly open: import("@angular/core").WritableSignal<boolean>;
  protected readonly activeIndex: import("@angular/core").WritableSignal<number>;
  private readonly elementRef;
  private readonly inputEl;
  private readonly menu;
  protected readonly filteredOptions: import("@angular/core").Signal<string[]>;
  constructor();
  protected onInput(event: Event): void;
  protected onFocus(): void;
  protected onKeydown(event: KeyboardEvent): void;
  protected selectOption(option: string): void;
  protected highlightParts(label: string): RsAutocompleteHighlight;
  private commitValue;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsAutocomplete, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsAutocomplete, "rs-autocomplete", never, {
    "options": {
      "alias": "options";
      "required": true;
      "isSignal": true;
    };
    "placeholder": {
      "alias": "placeholder";
      "required": false;
      "isSignal": true;
    };
    "query": {
      "alias": "query";
      "required": false;
      "isSignal": true;
    };
  }, {
    "query": "queryChange";
    "commit": "commit";
  }, never, never, true, never>;
}
/**
 * Eine Seite eines `RsWizard`, §18 der widgets-spaceship-Spezifikation. `canProceed` bildet das
 * "präventiv sperren"-Validierungsmuster ab (Referenz: Seite 1 sperrt "Weiter" direkt anhand des
 * Namensfelds), `validate` das "Fehler nach Klick zeigen"-Muster (Referenz: Seite 3/Besatzung).
 * Eine Seite darf laut Spezifikation nur eines der beiden Muster nutzen.
 */
export declare class RsWizardPage {
  readonly title: import("@angular/core").InputSignal<string>;
  readonly description: import("@angular/core").InputSignal<string>;
  readonly canProceed: import("@angular/core").InputSignal<boolean>;
  readonly validate: import("@angular/core").InputSignal<(() => boolean) | null>;
  readonly errorMessage: import("@angular/core").InputSignal<string>;
  /** Von `RsWizard` gesetzt — nicht selbst verändern. */
  readonly active: import("@angular/core").WritableSignal<boolean>;
  /** Von `RsWizard` gesetzt — nicht selbst verändern. */
  readonly showError: import("@angular/core").WritableSignal<boolean>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsWizardPage, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsWizardPage, "rs-wizard-page", never, {
    "title": {
      "alias": "title";
      "required": true;
      "isSignal": true;
    };
    "description": {
      "alias": "description";
      "required": false;
      "isSignal": true;
    };
    "canProceed": {
      "alias": "canProceed";
      "required": false;
      "isSignal": true;
    };
    "validate": {
      "alias": "validate";
      "required": false;
      "isSignal": true;
    };
    "errorMessage": {
      "alias": "errorMessage";
      "required": false;
      "isSignal": true;
    };
  }, {}, never, ["*"], true, never>;
}
export type RsWizardSize = 'md' | 'lg' | 'xl' | 'full';
/**
 * Mehrstufiger Dialog, §18 der widgets-spaceship-Spezifikation. Nutzt `.rs-modal-overlay` als
 * Hintergrund, schließt aber bewusst NICHT bei Klick auf den Hintergrund (nur ✕/Abbrechen/
 * Abschließen/Escape) — expliziter Unterschied zum normalen `RsModal`, um versehentlichen
 * Datenverlust bei Formulareingaben zu vermeiden. Schließen setzt keinen Zustand zurück; Reset
 * passiert beim nächsten Öffnen.
 */
export declare class RsWizard {
  readonly open: import("@angular/core").ModelSignal<boolean>;
  readonly title: import("@angular/core").InputSignal<string>;
  readonly size: import("@angular/core").InputSignal<RsWizardSize>;
  readonly horizontal: import("@angular/core").InputSignal<boolean>;
  protected readonly currentIndex: import("@angular/core").WritableSignal<number>;
  protected readonly unlockedIndex: import("@angular/core").WritableSignal<number>;
  protected readonly pages: import("@angular/core").Signal<readonly RsWizardPage[]>;
  protected readonly isLastPage: import("@angular/core").Signal<boolean>;
  constructor();
  protected close(): void;
  protected goTo(index: number): void;
  protected back(): void;
  protected next(): void;
  protected finish(): void;
  protected currentCanProceed(): boolean;
  protected stepHasError(index: number): boolean;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsWizard, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsWizard, "rs-wizard", never, {
    "open": {
      "alias": "open";
      "required": false;
      "isSignal": true;
    };
    "title": {
      "alias": "title";
      "required": false;
      "isSignal": true;
    };
    "size": {
      "alias": "size";
      "required": false;
      "isSignal": true;
    };
    "horizontal": {
      "alias": "horizontal";
      "required": false;
      "isSignal": true;
    };
  }, {
    "open": "openChange";
  }, ["pages"], ["*"], true, never>;
}
export type RsTableFilterType = 'text' | 'number' | 'datetime' | 'datetime-range' | 'custom';
/** Ausrichtung von Kopf und Zellen einer Spalte; `'end'` z. B. für Beträge. */
export type RsTableAlign = 'start' | 'end';
export interface RsTableCellContext<T> {
  $implicit: T;
}
export interface RsTableFilterContext {
  $implicit: unknown;
  commit: (value: unknown) => void;
}
/** `<ng-template rsCellDef let-row>...</ng-template>` — Zell-Inhalt für eine Spalte. */
export declare class RsCellDef<T = unknown> {
  readonly templateRef: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsCellDef<any>, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<RsCellDef<any>, "ng-template[rsCellDef]", never, {}, {}, never, never, true, never>;
}
/** `<ng-template rsFilterDef let-value let-commit="commit">...</ng-template>` — Custom-Filter-UI. */
export declare class RsFilterDef {
  readonly templateRef: TemplateRef<any>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsFilterDef, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<RsFilterDef, "ng-template[rsFilterDef]", never, {}, {}, never, never, true, never>;
}
/**
 * Spaltendefinition für `RsTable`, §21 der widgets-spaceship-Spezifikation. Löst die dort offen
 * gelassene Frage "Render-Funktionen → echte Components/ng-template" nach dem in Angular
 * etablierten Column-Def-Muster (vgl. Angular CDK/Material Table): `cellDef`/`filterDef` sind
 * `ng-template`s statt `(row) => HTMLElement`-Funktionen.
 */
export declare class RsTableColumn<T = unknown> {
  readonly key: import("@angular/core").InputSignal<string>;
  readonly header: import("@angular/core").InputSignal<string>;
  readonly width: import("@angular/core").InputSignal<number>;
  readonly minWidth: import("@angular/core").InputSignal<number>;
  readonly resizable: import("@angular/core").InputSignal<boolean>;
  readonly sortable: import("@angular/core").InputSignal<boolean>;
  readonly filterType: import("@angular/core").InputSignal<RsTableFilterType | null>;
  /**
   * Erweiterung gegenüber §21: Anteil am verbleibenden Platz. Gesetzt → Spaltenbreite
   * `minmax(<minWidth>px, <flex>fr)` statt fester Pixelbreite; solche Spalten sind nicht ziehbar.
   */
  readonly flex: import("@angular/core").InputSignal<number | null>;
  /** Erweiterung gegenüber §21: `'end'` richtet Kopf und Zellen rechtsbündig aus (Ziffern gleich breit). */
  readonly align: import("@angular/core").InputSignal<RsTableAlign>;
  /**
   * Erweiterung gegenüber §21: Text bricht an Wortgrenzen um, sehr lange Wörter notfalls im Wort;
   * Elemente eigener Zellen (Badges, Schaltflächen) rutschen in die nächste Zeile. Die Zeile wird
   * dann höher, die Tabelle bekommt den Modifier `rs-table--wrap`.
   */
  readonly wrap: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
  /**
   * Erweiterung gegenüber §21: begrenzt den Umbruch auf diese Zeilenzahl, danach „…“ und der volle
   * Text im `title`. Wirkt nur zusammen mit `wrap` und nur auf Textelemente (`rsTableText`, z. B.
   * die Standardzelle); `null` = unbegrenzt.
   */
  readonly maxLines: import("@angular/core").InputSignal<number | null>;
  readonly cellDef: import("@angular/core").Signal<RsCellDef<any> | undefined>;
  readonly filterDef: import("@angular/core").Signal<RsFilterDef | undefined>;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsTableColumn<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsTableColumn<any>, "rs-table-column", never, {
    "key": {
      "alias": "key";
      "required": true;
      "isSignal": true;
    };
    "header": {
      "alias": "header";
      "required": false;
      "isSignal": true;
    };
    "width": {
      "alias": "width";
      "required": false;
      "isSignal": true;
    };
    "minWidth": {
      "alias": "minWidth";
      "required": false;
      "isSignal": true;
    };
    "resizable": {
      "alias": "resizable";
      "required": false;
      "isSignal": true;
    };
    "sortable": {
      "alias": "sortable";
      "required": false;
      "isSignal": true;
    };
    "filterType": {
      "alias": "filterType";
      "required": false;
      "isSignal": true;
    };
    "flex": {
      "alias": "flex";
      "required": false;
      "isSignal": true;
    };
    "align": {
      "alias": "align";
      "required": false;
      "isSignal": true;
    };
    "wrap": {
      "alias": "wrap";
      "required": false;
      "isSignal": true;
    };
    "maxLines": {
      "alias": "maxLines";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["cellDef", "filterDef"], never, true, never>;
}
export type RsTableSort = {
  column: string;
  direction: 'asc' | 'desc';
} | null;
export type RsTableMode = 'pager' | 'infinite';
export interface RsTableRequest {
  page: number;
  pageSize: number;
  sort: RsTableSort;
  filters: Record<string, unknown>;
}
export interface RsTableResult<T> {
  rows: T[];
  total: number;
}
export type RsTableFetchFn<T> = (request: RsTableRequest) => Promise<RsTableResult<T>>;
/** Zusätzliche CSS-Klassen je Zeile, z. B. `'rs-table__row--muted'` für gedimmte Zeilen. */
export type RsTableRowClassFn<T> = (row: T) => string | readonly string[] | null | undefined;
export interface RsTableDateRange {
  from: Date | null;
  to: Date | null;
}
/**
 * Server-getriebene Tabelle, §21 der widgets-spaceship-Spezifikation — das komplexeste Widget.
 * Sortiert/filtert/paginiert NICHT selbst: sammelt nur den gewünschten Zustand (Seite,
 * Seitengröße, Sortierung, Filter) und ruft die vom Consumer übergebene `fetchData`-Funktion auf.
 * Jede Filter-/Sortier-Änderung setzt `page` auf 1 zurück, bevor neu geladen wird. Einzige
 * öffentliche Methode ist `reload()` (Vanilla-Vertrag: `{ reload }`-Rückgabe von `initTable`).
 *
 * Erweiterung gegenüber §21: Statt `fetchData` kann `data` ein fertig geladenes Array übergeben
 * (Modus „lokale Daten“: kein Pager, keine Sortierung/Filter, Höhe nach Inhalt). Genau einer der
 * beiden Inputs muss gesetzt sein.
 *
 * Erweiterung gegenüber §21: Spalten mit `wrap` brechen um, die Zeilen wachsen dann mit dem Inhalt
 * (`rs-table--wrap`). Ohne `wrap` bleiben Zeilen einzeilig; zu lange Texte der Standardzelle enden
 * mit „…“ (`RsTableText`).
 */
export declare class RsTable<T = unknown> {
  readonly fetchData: import("@angular/core").InputSignal<RsTableFetchFn<T> | undefined>;
  readonly data: import("@angular/core").InputSignal<readonly T[] | undefined>;
  readonly mode: import("@angular/core").InputSignal<RsTableMode>;
  readonly pageSizeOptions: import("@angular/core").InputSignal<readonly number[]>;
  readonly initialPageSize: import("@angular/core").InputSignal<number | undefined>;
  readonly rowClass: import("@angular/core").InputSignal<RsTableRowClassFn<T> | null>;
  /** Beschriftung der Tabelle für Screenreader (`aria-label`). */
  readonly label: import("@angular/core").InputSignal<string>;
  readonly columns: import("@angular/core").Signal<readonly RsTableColumn<any>[]>;
  private readonly scrollEl;
  protected readonly rows: import("@angular/core").WritableSignal<T[]>;
  protected readonly total: import("@angular/core").WritableSignal<number>;
  protected readonly page: import("@angular/core").WritableSignal<number>;
  protected readonly currentPageSize: import("@angular/core").WritableSignal<number>;
  protected readonly sort: import("@angular/core").WritableSignal<RsTableSort>;
  protected readonly filters: import("@angular/core").WritableSignal<Record<string, unknown>>;
  protected readonly rangeDrafts: import("@angular/core").WritableSignal<Record<string, RsTableDateRange>>;
  protected readonly loading: import("@angular/core").WritableSignal<boolean>;
  protected readonly error: import("@angular/core").WritableSignal<string | null>;
  protected readonly colWidths: import("@angular/core").WritableSignal<Record<string, number>>;
  /** Sichtbare Breite des Scrollbereichs, begrenzt Lade-/Leer-/Fehlerzeile auf den sichtbaren Teil. */
  protected readonly visibleWidth: import("@angular/core").WritableSignal<number | null>;
  /** Lokale Daten statt `fetchData`. */
  protected readonly clientMode: import("@angular/core").Signal<boolean>;
  protected readonly renderedRows: import("@angular/core").Signal<{
    row: T;
    classes: string | string[] | null;
  }[]>;
  /** Mindestens eine Spalte bricht um: Zeilen haben dann eine Mindest- statt einer festen Höhe. */
  protected readonly hasWrap: import("@angular/core").Signal<boolean>;
  protected readonly showFilterRow: import("@angular/core").Signal<boolean>;
  protected readonly tableCols: import("@angular/core").Signal<string>;
  /**
   * Gemeinsame Mindestbreite aller Zeilen und des Körpers. Bei rein festen Spalten identisch mit
   * der bisherigen `max-content`-Breite; bei `flex`-Spalten hält sie Kopf und Zeilen untereinander,
   * deren `max-content`-Breite sonst vom jeweiligen Inhalt abhinge.
   */
  protected readonly tableMinWidth: import("@angular/core").Signal<number>;
  protected readonly totalPages: import("@angular/core").Signal<number>;
  protected readonly rangeStart: import("@angular/core").Signal<number>;
  protected readonly rangeEnd: import("@angular/core").Signal<number>;
  protected readonly hasMore: import("@angular/core").Signal<boolean>;
  constructor();
  ngOnInit(): void;
  /**
   * Vanilla-Vertrag: `{ reload }` — lädt die aktuelle Seite mit unverändertem Zustand neu.
   * Bei lokalen Daten ohne Wirkung, die Tabelle folgt dann direkt dem `data`-Signal.
   */
  reload(): void;
  /** Sortierbar nur im servergetriebenen Modus. */
  protected isSortable(col: RsTableColumn): boolean;
  protected ariaSort(col: RsTableColumn): 'ascending' | 'descending' | 'none' | null;
  protected filterLabel(col: RsTableColumn): string;
  protected toggleSort(key: string): void;
  protected commitFilter(key: string, value: unknown): void;
  protected commitRangeFilter(key: string, part: 'from' | 'to', value: Date | null): void;
  /** Zeilenbegrenzung einer umbrechenden Spalte, sonst `null`. */
  protected maxLines(col: RsTableColumn): number | null;
  protected cellValue(row: T, key: string): string;
  protected makeCommitFn(key: string): (value: unknown) => void;
  protected clearFilter(key: string, input?: HTMLInputElement): void;
  protected goToPage(delta: number): void;
  protected changePageSize(size: number): void;
  protected onBodyScroll(event: Event): void;
  protected startResize(event: MouseEvent, key: string): void;
  private load;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsTable<any>, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsTable<any>, "rs-table", never, {
    "fetchData": {
      "alias": "fetchData";
      "required": false;
      "isSignal": true;
    };
    "data": {
      "alias": "data";
      "required": false;
      "isSignal": true;
    };
    "mode": {
      "alias": "mode";
      "required": false;
      "isSignal": true;
    };
    "pageSizeOptions": {
      "alias": "pageSizeOptions";
      "required": false;
      "isSignal": true;
    };
    "initialPageSize": {
      "alias": "pageSize";
      "required": false;
      "isSignal": true;
    };
    "rowClass": {
      "alias": "rowClass";
      "required": false;
      "isSignal": true;
    };
    "label": {
      "alias": "label";
      "required": false;
      "isSignal": true;
    };
  }, {}, ["columns"], never, true, never>;
}
/**
 * Erweiterung gegenüber §21: Textelement einer Tabellenzelle (`<span rsTableText>`). Setzt die
 * Klasse `rs-table__text`, die zu langen Text mit „…“ kürzt (mit `wrap` und `maxLines` nach der
 * letzten erlaubten Zeile). Ist der Text gekürzt, steht er beim Überfahren mit der Maus vollständig
 * im `title`; sonst entfernt die Direktive `title` wieder. Die Standardzelle nutzt sie selbst, in
 * eigenen Zellen (`rsCellDef`) setzt der Consumer sie an sein Textelement.
 *
 * Gemessen wird erst beim Überfahren: Das braucht keinen Beobachter je Zelle und stimmt auch nach
 * einem Spalten-Resize.
 */
export declare class RsTableText {
  private readonly element;
  protected updateTitle(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsTableText, never>;
  static ɵdir: i0.ɵɵDirectiveDeclaration<RsTableText, "[rsTableText]", never, {}, {}, never, never, true, never>;
}
export type RsToastVariant = 'neutral' | 'ok' | 'warn' | 'crit';
/** Eine Aktion im Toast, z. B. „Rückgängig“. Ein Klick ruft `handler` auf und schließt den Toast. */
export interface RsToastAction {
  label: string;
  handler: () => void;
}
export interface RsToastOptions {
  message: string;
  title?: string;
  /** Standard `'neutral'`. */
  variant?: RsToastVariant;
  action?: RsToastAction;
  /** Anzeigedauer in ms, Standard 6000; `0` = bleibt bis zum Schließen. */
  duration?: number;
  /** Ob der Toast eine Schließen-Schaltfläche hat und per Escape schließt. Standard `true`. */
  dismissible?: boolean;
}
/** Ein sichtbarer Toast mit aufgelösten Standardwerten. */
export interface RsToast {
  readonly id: number;
  readonly message: string;
  readonly title?: string;
  readonly variant: RsToastVariant;
  readonly action?: RsToastAction;
  readonly duration: number;
  readonly dismissible: boolean;
}
export interface RsToastRef {
  readonly id: number;
  dismiss(): void;
}
/**
 * Nicht-blockierende Kurzmeldungen. Eigene Ergänzung dieser Bibliothek, kein Abschnitt in der
 * Spezifikation (Vertrag: documentation/angular component widgets/toast.md).
 *
 * Der Service hält nur die Liste der sichtbaren Toasts (höchstens 3, der älteste fällt raus).
 * Angezeigt und zeitgesteuert ausgeblendet werden sie von `<rs-toast-host />`, das einmal in der
 * App stehen muss — ohne Host verschwinden Toasts nicht von selbst.
 */
export declare class RsToastService {
  private readonly _toasts;
  /** Sichtbare Toasts, der älteste zuerst. */
  readonly toasts: import("@angular/core").Signal<readonly RsToast[]>;
  private nextId;
  show(options: RsToastOptions): RsToastRef;
  dismiss(id: number): void;
  clear(): void;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsToastService, never>;
  static ɵprov: i0.ɵɵInjectableDeclaration<any>;
}
/**
 * Zeigt die Toasts aus `RsToastService` an. Einmal in der App platzieren (z. B. am Ende der
 * App-Shell); ohne Host verschwinden Toasts nicht von selbst.
 *
 * Für Screenreader enthält der Host zwei unsichtbare Live-Regionen, die immer im DOM sind:
 * `aria-live="polite"` und `role="alert"` (Variante `crit`). Dort erscheint der Text jedes neuen
 * Toasts. Die sichtbaren Toasts selbst sind keine Live-Region, sonst würden manche Meldungen
 * doppelt angesagt (Muster wie der `LiveAnnouncer` des Angular CDK).
 */
export declare class RsToastHost {
  protected readonly service: RsToastService;
  /**
   * Der zuletzt neu angezeigte Toast, solange er sichtbar ist. Wird ein neuerer Toast geschlossen,
   * fällt die Ansage weg statt auf einen älteren Toast zurückzuspringen (der sonst erneut
   * angesagt würde).
   */
  private readonly announced;
  protected readonly politeAnnouncement: import("@angular/core").Signal<RsToast[]>;
  protected readonly alertAnnouncement: import("@angular/core").Signal<RsToast[]>;
  protected announcementText(toast: RsToast): string;
  static ɵfac: i0.ɵɵFactoryDeclaration<RsToastHost, never>;
  static ɵcmp: i0.ɵɵComponentDeclaration<RsToastHost, "rs-toast-host", never, {}, {}, never, never, true, never>;
}