import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, Directive, ElementRef, HostAttributeToken, Injectable, TemplateRef, afterNextRender, afterRenderEffect, booleanAttribute, computed, contentChild, contentChildren, effect, inject, input, linkedSignal, model, output, signal, viewChild } from "@angular/core";
import { NgTemplateOutlet } from "@angular/common";
function flipIfNeeded(anchorEl, popupEl, upClass, gap) {
	const anchorRect = anchorEl.getBoundingClientRect();
	const spaceBelow = window.innerHeight - anchorRect.bottom - gap;
	const spaceAbove = anchorRect.top - gap;
	const opensUp = popupEl.offsetHeight > spaceBelow && spaceAbove > spaceBelow;
	popupEl.classList.toggle(upClass, opensUp);
}
function registerDismissibleOverlay(options) {
	const destroyRef = inject(DestroyRef);
	const closeOnOutsideClick = options.closeOnOutsideClick ?? true;
	const onDocumentClick = (event) => {
		if (!options.isOpen() || !closeOnOutsideClick) return;
		if (event.target instanceof Node && options.isInside(event.target)) return;
		options.close();
	};
	const onDocumentKeydown = (event) => {
		if (!options.isOpen()) return;
		if (event.key === "Escape") options.close();
	};
	document.addEventListener("click", onDocumentClick);
	document.addEventListener("keydown", onDocumentKeydown);
	destroyRef.onDestroy(() => {
		document.removeEventListener("click", onDocumentClick);
		document.removeEventListener("keydown", onDocumentKeydown);
	});
}
function registerAnchoredPopup(options) {
	const resizeObserver = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(() => place());
	let observedAnchor = null;
	const place = () => {
		const popupEl = options.popup();
		const anchorEl = popupEl && options.anchor();
		if (!popupEl || !anchorEl) return;
		placeAnchoredPopup(anchorEl, popupEl, options);
		if (resizeObserver && anchorEl !== observedAnchor) {
			resizeObserver.disconnect();
			resizeObserver.observe(anchorEl);
			observedAnchor = anchorEl;
		}
	};
	window.addEventListener("scroll", place, {
		capture: true,
		passive: true
	});
	window.addEventListener("resize", place);
	inject(DestroyRef).onDestroy(() => {
		resizeObserver?.disconnect();
		window.removeEventListener("scroll", place, { capture: true });
		window.removeEventListener("resize", place);
	});
	return place;
}
function placeAnchoredPopup(anchorEl, popupEl, options) {
	if (typeof popupEl.showPopover === "function" && !popupEl.matches(":popover-open")) popupEl.showPopover();
	const anchor = anchorEl.getBoundingClientRect();
	if (options.matchWidth) popupEl.style.width = `${anchor.width}px`;
	const viewport = document.documentElement;
	const { gap } = options;
	const height = popupEl.offsetHeight;
	const above = opensAbove(anchor, height, viewport.clientHeight, options);
	if (options.upClass) popupEl.classList.toggle(options.upClass, above);
	const desiredTop = above ? anchor.top - gap - height : anchor.bottom + gap;
	let top = Math.max(0, Math.min(desiredTop, viewport.clientHeight - height));
	top = Math.max(anchor.top - gap - height, Math.min(top, anchor.bottom + gap));
	if (above && top === desiredTop) {
		popupEl.style.top = "auto";
		popupEl.style.bottom = `${viewport.clientHeight - anchor.top + gap}px`;
	} else {
		popupEl.style.top = `${top}px`;
		popupEl.style.bottom = "auto";
	}
	const width = popupEl.offsetWidth;
	const align = resolve(options.align) ?? "start";
	const rtl = getComputedStyle(popupEl).direction === "rtl";
	let left;
	if (align === "center") left = anchor.left + (anchor.width - width) / 2;
	else left = align === "start" !== rtl ? anchor.left : anchor.right - width;
	popupEl.style.left = `${Math.max(0, Math.min(left, viewport.clientWidth - width))}px`;
	popupEl.style.right = "auto";
}
function opensAbove(anchor, height, viewportHeight, options) {
	const spaceBelow = viewportHeight - anchor.bottom - options.gap;
	const spaceAbove = anchor.top - options.gap;
	const flip = options.flip ?? true;
	if (resolve(options.side) === "above") return !(flip && height > spaceAbove && spaceBelow > spaceAbove);
	return flip && height > spaceBelow && spaceAbove > spaceBelow;
}
function resolve(value) {
	return typeof value === "function" ? value() : value;
}
var RsToggle = class RsToggle {
	checked = model(false, ...ngDevMode ? [{ debugName: "checked" }] : /* istanbul ignore next */ []);
	status = input("green", ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	toggle() {
		if (this.disabled()) return;
		this.checked.update((value) => !value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsToggle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: RsToggle,
		isStandalone: true,
		selector: "rs-toggle",
		inputs: {
			checked: {
				classPropertyName: "checked",
				publicName: "checked",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { checked: "checkedChange" },
		ngImport: i0,
		template: "<button\n  type=\"button\"\n  class=\"rs-toggle\"\n  [class.rs-toggle--yellow]=\"status() === 'yellow'\"\n  [class.rs-toggle--red]=\"status() === 'red'\"\n  role=\"switch\"\n  [attr.aria-checked]=\"checked()\"\n  [disabled]=\"disabled()\"\n  (click)=\"toggle()\"\n>\n  <span class=\"rs-toggle__track\"><span class=\"rs-toggle__thumb\"></span></span>\n</button>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsToggle,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-toggle",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<button\n  type=\"button\"\n  class=\"rs-toggle\"\n  [class.rs-toggle--yellow]=\"status() === 'yellow'\"\n  [class.rs-toggle--red]=\"status() === 'red'\"\n  role=\"switch\"\n  [attr.aria-checked]=\"checked()\"\n  [disabled]=\"disabled()\"\n  (click)=\"toggle()\"\n>\n  <span class=\"rs-toggle__track\"><span class=\"rs-toggle__thumb\"></span></span>\n</button>\n"
		}]
	}],
	propDecorators: {
		checked: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "checked",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["checkedChange"]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}]
	}
});
var RsAccordion = class RsAccordion {
	openItem = signal(null, ...ngDevMode ? [{ debugName: "openItem" }] : /* istanbul ignore next */ []);
	isOpen(item) {
		return this.openItem() === item;
	}
	toggle(item) {
		this.openItem.update((current) => current === item ? null : item);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsAccordion,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: RsAccordion,
		isStandalone: true,
		selector: "rs-accordion",
		ngImport: i0,
		template: `<div class="rs-accordion"><ng-content /></div>`,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsAccordion,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-accordion",
			template: `<div class="rs-accordion"><ng-content /></div>`,
			changeDetection: ChangeDetectionStrategy.OnPush
		}]
	}]
});
var RsAccordionItem = class RsAccordionItem {
	accordion = inject(RsAccordion);
	header = input.required(...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	get expanded() {
		return this.accordion.isOpen(this);
	}
	toggle() {
		this.accordion.toggle(this);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsAccordionItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: RsAccordionItem,
		isStandalone: true,
		selector: "rs-accordion-item",
		inputs: { header: {
			classPropertyName: "header",
			publicName: "header",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		ngImport: i0,
		template: "<div class=\"rs-accordion__item\">\n  <button\n    type=\"button\"\n    class=\"rs-accordion__trigger\"\n    [attr.aria-expanded]=\"expanded\"\n    (click)=\"toggle()\"\n  >\n    {{ header() }}\n    <span class=\"rs-accordion__icon\"></span>\n  </button>\n  <div class=\"rs-accordion__panel\" [hidden]=\"!expanded\">\n    <ng-content />\n  </div>\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsAccordionItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-accordion-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"rs-accordion__item\">\n  <button\n    type=\"button\"\n    class=\"rs-accordion__trigger\"\n    [attr.aria-expanded]=\"expanded\"\n    (click)=\"toggle()\"\n  >\n    {{ header() }}\n    <span class=\"rs-accordion__icon\"></span>\n  </button>\n  <div class=\"rs-accordion__panel\" [hidden]=\"!expanded\">\n    <ng-content />\n  </div>\n</div>\n"
		}]
	}],
	propDecorators: { header: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "header",
			required: true
		}]
	}] }
});
var RsTabs = class RsTabs {
	items = input.required(...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	activeIndex = model(0, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsTabs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsTabs,
		isStandalone: true,
		selector: "rs-tabs",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			activeIndex: {
				classPropertyName: "activeIndex",
				publicName: "activeIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { activeIndex: "activeIndexChange" },
		ngImport: i0,
		template: "<div class=\"rs-tabs\">\n  @for (item of items(); track $index) {\n    <button\n      type=\"button\"\n      class=\"rs-tabs__item\"\n      [class.rs-tabs__item--active]=\"$index === activeIndex()\"\n      (click)=\"activeIndex.set($index)\"\n    >\n      {{ item }}\n    </button>\n  }\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsTabs,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-tabs",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"rs-tabs\">\n  @for (item of items(); track $index) {\n    <button\n      type=\"button\"\n      class=\"rs-tabs__item\"\n      [class.rs-tabs__item--active]=\"$index === activeIndex()\"\n      (click)=\"activeIndex.set($index)\"\n    >\n      {{ item }}\n    </button>\n  }\n</div>\n"
		}]
	}],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: true
			}]
		}],
		activeIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeIndex",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["activeIndexChange"]
		}]
	}
});
var RsSidenav = class RsSidenav {
	items = input.required(...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	activeIndex = model(0, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsSidenav,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsSidenav,
		isStandalone: true,
		selector: "rs-sidenav",
		inputs: {
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			activeIndex: {
				classPropertyName: "activeIndex",
				publicName: "activeIndex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { activeIndex: "activeIndexChange" },
		ngImport: i0,
		template: "<nav class=\"rs-sidenav\">\n  @for (item of items(); track $index) {\n    <button\n      type=\"button\"\n      class=\"rs-sidenav__item\"\n      [class.rs-sidenav__item--active]=\"$index === activeIndex()\"\n      (click)=\"activeIndex.set($index)\"\n    >\n      {{ item }}\n    </button>\n  }\n</nav>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsSidenav,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-sidenav",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<nav class=\"rs-sidenav\">\n  @for (item of items(); track $index) {\n    <button\n      type=\"button\"\n      class=\"rs-sidenav__item\"\n      [class.rs-sidenav__item--active]=\"$index === activeIndex()\"\n      (click)=\"activeIndex.set($index)\"\n    >\n      {{ item }}\n    </button>\n  }\n</nav>\n"
		}]
	}],
	propDecorators: {
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: true
			}]
		}],
		activeIndex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "activeIndex",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["activeIndexChange"]
		}]
	}
});
const RS_GAUGE_ROUND_CIRCUMFERENCE = 314.16;
var RsGauge = class RsGauge {
	variant = input("round", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	value = input.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	status = input("ok", ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	circumference = RS_GAUGE_ROUND_CIRCUMFERENCE;
	renderedOffset = signal(RS_GAUGE_ROUND_CIRCUMFERENCE, ...ngDevMode ? [{ debugName: "renderedOffset" }] : /* istanbul ignore next */ []);
	mounted = false;
	constructor() {
		afterNextRender(() => {
			this.mounted = true;
			this.renderedOffset.set(this.targetOffset());
		});
		effect(() => {
			const target = this.targetOffset();
			if (this.mounted) this.renderedOffset.set(target);
		});
	}
	targetOffset() {
		const pct = Math.min(100, Math.max(0, this.value()));
		return this.circumference - this.circumference * pct / 100;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsGauge,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsGauge,
		isStandalone: true,
		selector: "rs-gauge",
		inputs: {
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "@if (variant() === 'round') {\n  <div\n    class=\"rs-gauge-round\"\n    [class.rs-gauge-round--warn]=\"status() === 'warn'\"\n    [class.rs-gauge-round--crit]=\"status() === 'crit'\"\n  >\n    <svg viewBox=\"0 0 120 120\">\n      <circle class=\"rs-gauge-round__track\" cx=\"60\" cy=\"60\" r=\"50\"></circle>\n      <circle\n        class=\"rs-gauge-round__fill\"\n        cx=\"60\"\n        cy=\"60\"\n        r=\"50\"\n        [attr.stroke-dasharray]=\"circumference\"\n        [attr.stroke-dashoffset]=\"renderedOffset()\"\n      ></circle>\n    </svg>\n    <div class=\"rs-gauge-round__value\">\n      <span>{{ value() }}%</span>\n      @if (label()) {\n        <span class=\"rs-gauge-round__caption\">{{ label() }}</span>\n      }\n    </div>\n  </div>\n} @else {\n  <div\n    class=\"rs-gauge-bar\"\n    [class.rs-gauge-bar--warn]=\"status() === 'warn'\"\n    [class.rs-gauge-bar--crit]=\"status() === 'crit'\"\n  >\n    <div class=\"rs-gauge-bar__label\">\n      <span>{{ label() }}</span><span>{{ value() }}%</span>\n    </div>\n    <div class=\"rs-gauge-bar__track\">\n      <div class=\"rs-gauge-bar__fill\" [style.--rs-gauge-pct]=\"value()\"></div>\n    </div>\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsGauge,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-gauge",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "@if (variant() === 'round') {\n  <div\n    class=\"rs-gauge-round\"\n    [class.rs-gauge-round--warn]=\"status() === 'warn'\"\n    [class.rs-gauge-round--crit]=\"status() === 'crit'\"\n  >\n    <svg viewBox=\"0 0 120 120\">\n      <circle class=\"rs-gauge-round__track\" cx=\"60\" cy=\"60\" r=\"50\"></circle>\n      <circle\n        class=\"rs-gauge-round__fill\"\n        cx=\"60\"\n        cy=\"60\"\n        r=\"50\"\n        [attr.stroke-dasharray]=\"circumference\"\n        [attr.stroke-dashoffset]=\"renderedOffset()\"\n      ></circle>\n    </svg>\n    <div class=\"rs-gauge-round__value\">\n      <span>{{ value() }}%</span>\n      @if (label()) {\n        <span class=\"rs-gauge-round__caption\">{{ label() }}</span>\n      }\n    </div>\n  </div>\n} @else {\n  <div\n    class=\"rs-gauge-bar\"\n    [class.rs-gauge-bar--warn]=\"status() === 'warn'\"\n    [class.rs-gauge-bar--crit]=\"status() === 'crit'\"\n  >\n    <div class=\"rs-gauge-bar__label\">\n      <span>{{ label() }}</span><span>{{ value() }}%</span>\n    </div>\n    <div class=\"rs-gauge-bar__track\">\n      <div class=\"rs-gauge-bar__fill\" [style.--rs-gauge-pct]=\"value()\"></div>\n    </div>\n  </div>\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}]
	}
});
var RsLogPanel = class RsLogPanel {
	entries = input.required(...ngDevMode ? [{ debugName: "entries" }] : /* istanbul ignore next */ []);
	list = viewChild.required("list", ...ngDevMode ? [{ debugName: "list" }] : /* istanbul ignore next */ []);
	constructor() {
		afterRenderEffect(() => {
			this.entries();
			const el = this.list().nativeElement;
			el.scrollTop = el.scrollHeight;
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsLogPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsLogPanel,
		isStandalone: true,
		selector: "rs-log-panel",
		inputs: { entries: {
			classPropertyName: "entries",
			publicName: "entries",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		viewQueries: [{
			propertyName: "list",
			first: true,
			predicate: ["list"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div class=\"rs-log\">\n  <div class=\"rs-log__list\" #list>\n    @for (entry of entries(); track $index) {\n      <div\n        class=\"rs-log__entry\"\n        [class.rs-log__entry--warn]=\"entry.severity === 'warn'\"\n        [class.rs-log__entry--crit]=\"entry.severity === 'crit'\"\n      >\n        <span class=\"rs-log__time\">{{ entry.time }}</span>\n        <span class=\"rs-log__msg\">{{ entry.message }}</span>\n      </div>\n    }\n  </div>\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsLogPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-log-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"rs-log\">\n  <div class=\"rs-log__list\" #list>\n    @for (entry of entries(); track $index) {\n      <div\n        class=\"rs-log__entry\"\n        [class.rs-log__entry--warn]=\"entry.severity === 'warn'\"\n        [class.rs-log__entry--crit]=\"entry.severity === 'crit'\"\n      >\n        <span class=\"rs-log__time\">{{ entry.time }}</span>\n        <span class=\"rs-log__msg\">{{ entry.message }}</span>\n      </div>\n    }\n  </div>\n</div>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		entries: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "entries",
				required: true
			}]
		}],
		list: [{
			type: i0.ViewChild,
			args: ["list", { isSignal: true }]
		}]
	}
});
var RsPasswordField = class RsPasswordField {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	hint = input("", ...ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []);
	status = input("default", ...ngDevMode ? [{ debugName: "status" }] : /* istanbul ignore next */ []);
	disabled = input(false, ...ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []);
	value = model("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	visible = signal(false, ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	toggleVisibility() {
		this.visible.update((value) => !value);
	}
	onInput(event) {
		this.value.set(event.target.value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsPasswordField,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsPasswordField,
		isStandalone: true,
		selector: "rs-password-field",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			hint: {
				classPropertyName: "hint",
				publicName: "hint",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			status: {
				classPropertyName: "status",
				publicName: "status",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { value: "valueChange" },
		ngImport: i0,
		template: "<label\n  class=\"rs-field\"\n  [class.rs-field--error]=\"status() === 'error'\"\n  [class.rs-field--warn]=\"status() === 'warn'\"\n>\n  @if (label()) {\n    <span class=\"rs-field__label\">{{ label() }}</span>\n  }\n  <span class=\"rs-input-group\">\n    <input\n      class=\"rs-input\"\n      [type]=\"visible() ? 'text' : 'password'\"\n      [value]=\"value()\"\n      [disabled]=\"disabled()\"\n      (input)=\"onInput($event)\"\n    />\n    <button\n      type=\"button\"\n      class=\"rs-input-group__btn\"\n      [attr.aria-label]=\"visible() ? 'Passwort verbergen' : 'Passwort anzeigen'\"\n      (click)=\"toggleVisibility()\"\n    >\n      {{ visible() ? '🙈' : '👁' }}\n    </button>\n  </span>\n  @if (hint()) {\n    <span class=\"rs-field__hint\">{{ hint() }}</span>\n  }\n</label>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsPasswordField,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-password-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<label\n  class=\"rs-field\"\n  [class.rs-field--error]=\"status() === 'error'\"\n  [class.rs-field--warn]=\"status() === 'warn'\"\n>\n  @if (label()) {\n    <span class=\"rs-field__label\">{{ label() }}</span>\n  }\n  <span class=\"rs-input-group\">\n    <input\n      class=\"rs-input\"\n      [type]=\"visible() ? 'text' : 'password'\"\n      [value]=\"value()\"\n      [disabled]=\"disabled()\"\n      (input)=\"onInput($event)\"\n    />\n    <button\n      type=\"button\"\n      class=\"rs-input-group__btn\"\n      [attr.aria-label]=\"visible() ? 'Passwort verbergen' : 'Passwort anzeigen'\"\n      (click)=\"toggleVisibility()\"\n    >\n      {{ visible() ? '🙈' : '👁' }}\n    </button>\n  </span>\n  @if (hint()) {\n    <span class=\"rs-field__hint\">{{ hint() }}</span>\n  }\n</label>\n"
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		hint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hint",
				required: false
			}]
		}],
		status: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "status",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}]
	}
});
var RsModal = class RsModal {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	variant = input("info", ...ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []);
	panel = viewChild("panel", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	constructor() {
		registerDismissibleOverlay({
			isOpen: () => this.open(),
			close: () => this.open.set(false),
			isInside: (target) => this.panel()?.nativeElement.contains(target) ?? false
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsModal,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsModal,
		isStandalone: true,
		selector: "rs-modal",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			variant: {
				classPropertyName: "variant",
				publicName: "variant",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		viewQueries: [{
			propertyName: "panel",
			first: true,
			predicate: ["panel"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (open()) {\n  <div class=\"rs-modal-overlay\">\n    <div\n      class=\"rs-modal\"\n      [class.rs-modal--confirm]=\"variant() === 'confirm'\"\n      [class.rs-modal--crit]=\"variant() === 'crit'\"\n      #panel\n    >\n      @if (title()) {\n        <h3 class=\"rs-modal__title\">{{ title() }}</h3>\n      }\n      <ng-content />\n    </div>\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsModal,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-modal",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "@if (open()) {\n  <div class=\"rs-modal-overlay\">\n    <div\n      class=\"rs-modal\"\n      [class.rs-modal--confirm]=\"variant() === 'confirm'\"\n      [class.rs-modal--crit]=\"variant() === 'crit'\"\n      #panel\n    >\n      @if (title()) {\n        <h3 class=\"rs-modal__title\">{{ title() }}</h3>\n      }\n      <ng-content />\n    </div>\n  </div>\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		variant: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "variant",
				required: false
			}]
		}],
		panel: [{
			type: i0.ViewChild,
			args: ["panel", { isSignal: true }]
		}]
	}
});
var RsPopover = class RsPopover {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	elementRef = inject(ElementRef);
	panel = viewChild("panel", ...ngDevMode ? [{ debugName: "panel" }] : /* istanbul ignore next */ []);
	triggerEl = null;
	constructor() {
		registerDismissibleOverlay({
			isOpen: () => this.open(),
			close: () => this.open.set(false),
			isInside: (target) => (this.triggerEl?.contains(target) ?? false) || (this.panel()?.nativeElement.contains(target) ?? false)
		});
		const placePanel = registerAnchoredPopup({
			anchor: () => this.triggerEl ?? this.elementRef.nativeElement.parentElement ?? void 0,
			popup: () => this.panel()?.nativeElement,
			gap: 10,
			flip: false,
			align: () => this.contextAlign()
		});
		afterRenderEffect(() => {
			if (this.panel()) placePanel();
		});
	}
	registerTrigger(el) {
		this.triggerEl = el;
	}
	toggle() {
		this.open.update((value) => !value);
	}
	contextAlign() {
		const panel = this.panel()?.nativeElement;
		return (panel && getComputedStyle(panel).getPropertyValue("--rs-popover-align").trim()) === "end" ? "end" : "start";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsPopover,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsPopover,
		isStandalone: true,
		selector: "rs-popover",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		viewQueries: [{
			propertyName: "panel",
			first: true,
			predicate: ["panel"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (open()) {\n  <div class=\"rs-popover\" popover=\"manual\" #panel>\n    @if (title()) {\n      <h4 class=\"rs-popover__title\">{{ title() }}</h4>\n    }\n    <div class=\"rs-popover__content\"><ng-content /></div>\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsPopover,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-popover",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "@if (open()) {\n  <div class=\"rs-popover\" popover=\"manual\" #panel>\n    @if (title()) {\n      <h4 class=\"rs-popover__title\">{{ title() }}</h4>\n    }\n    <div class=\"rs-popover__content\"><ng-content /></div>\n  </div>\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		panel: [{
			type: i0.ViewChild,
			args: ["panel", { isSignal: true }]
		}]
	}
});
var RsPopoverTrigger = class RsPopoverTrigger {
	elementRef = inject(ElementRef);
	rsPopoverTrigger = input.required(...ngDevMode ? [{ debugName: "rsPopoverTrigger" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			this.rsPopoverTrigger().registerTrigger(this.elementRef.nativeElement);
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsPopoverTrigger,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: RsPopoverTrigger,
		isStandalone: true,
		selector: "[rsPopoverTrigger]",
		inputs: { rsPopoverTrigger: {
			classPropertyName: "rsPopoverTrigger",
			publicName: "rsPopoverTrigger",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			listeners: { "click": "rsPopoverTrigger().toggle()" },
			properties: { "attr.aria-expanded": "rsPopoverTrigger().open()" }
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsPopoverTrigger,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[rsPopoverTrigger]",
			host: {
				"[attr.aria-expanded]": "rsPopoverTrigger().open()",
				"(click)": "rsPopoverTrigger().toggle()"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { rsPopoverTrigger: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "rsPopoverTrigger",
			required: true
		}]
	}] }
});
let nextId = 0;
var RsTooltip = class RsTooltip {
	text = input.required({
		...ngDevMode ? { debugName: "text" } : /* istanbul ignore next */ {},
		alias: "data-tooltip"
	});
	position = input("top", {
		...ngDevMode ? { debugName: "position" } : /* istanbul ignore next */ {},
		alias: "data-tooltip-pos"
	});
	host = inject(ElementRef).nativeElement;
	tooltipEl = createTooltipElement();
	hovered = signal(false, ...ngDevMode ? [{ debugName: "hovered" }] : /* istanbul ignore next */ []);
	focusVisible = signal(false, ...ngDevMode ? [{ debugName: "focusVisible" }] : /* istanbul ignore next */ []);
	dismissed = signal(false, ...ngDevMode ? [{ debugName: "dismissed" }] : /* istanbul ignore next */ []);
	visible = computed(() => (this.hovered() || this.focusVisible()) && !this.dismissed() && this.text() !== "", ...ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []);
	describedBy = [inject(new HostAttributeToken("aria-describedby"), { optional: true }), this.tooltipEl.id].filter(Boolean).join(" ");
	constructor() {
		document.body.append(this.tooltipEl);
		inject(DestroyRef).onDestroy(() => this.tooltipEl.remove());
		const place = registerAnchoredPopup({
			anchor: () => this.host,
			popup: () => this.visible() ? this.tooltipEl : void 0,
			gap: 8,
			side: () => this.position() === "bottom" ? "below" : "above",
			align: "center"
		});
		let shown = false;
		afterRenderEffect(() => {
			this.tooltipEl.textContent = this.text();
			if (this.visible()) {
				place();
				shown = true;
			} else if (shown) {
				shown = false;
				if (typeof this.tooltipEl.hidePopover === "function") this.tooltipEl.hidePopover();
			}
		});
	}
	onHover(hovered) {
		this.hovered.set(hovered);
		if (hovered) this.dismissed.set(false);
	}
	onFocus() {
		this.focusVisible.set(this.host.matches(":focus-visible"));
		this.dismissed.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsTooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.0",
		type: RsTooltip,
		isStandalone: true,
		selector: "[data-tooltip]",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "data-tooltip",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "data-tooltip-pos",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			listeners: {
				"mouseenter": "onHover(true)",
				"mouseleave": "onHover(false)",
				"focus": "onFocus()",
				"blur": "focusVisible.set(false)",
				"document:keydown.escape": "dismissed.set(true)"
			},
			properties: { "attr.aria-describedby": "describedBy" },
			classAttribute: "rs-tooltip-host"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsTooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[data-tooltip]",
			host: {
				class: "rs-tooltip-host",
				"[attr.aria-describedby]": "describedBy",
				"(mouseenter)": "onHover(true)",
				"(mouseleave)": "onHover(false)",
				"(focus)": "onFocus()",
				"(blur)": "focusVisible.set(false)",
				"(document:keydown.escape)": "dismissed.set(true)"
			}
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "data-tooltip",
				required: true
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "data-tooltip-pos",
				required: false
			}]
		}]
	}
});
function createTooltipElement() {
	const el = document.createElement("span");
	el.id = `rs-tooltip-${nextId++}`;
	el.className = "rs-tooltip";
	el.setAttribute("role", "tooltip");
	el.setAttribute("popover", "manual");
	return el;
}
var RsDropdown = class RsDropdown {
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	multi = input(false, ...ngDevMode ? [{ debugName: "multi" }] : /* istanbul ignore next */ []);
	searchable = input(false, ...ngDevMode ? [{ debugName: "searchable" }] : /* istanbul ignore next */ []);
	placeholder = input("Bitte wählen", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	values = model([], ...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	query = signal("", ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	focusSearchPending = false;
	trigger = viewChild("trigger", ...ngDevMode ? [{ debugName: "trigger" }] : /* istanbul ignore next */ []);
	menu = viewChild("menu", ...ngDevMode ? [{ debugName: "menu" }] : /* istanbul ignore next */ []);
	searchInput = viewChild("searchInput", ...ngDevMode ? [{ debugName: "searchInput" }] : /* istanbul ignore next */ []);
	filteredOptions = computed(() => {
		const q = this.query().trim().toLowerCase();
		if (!q) return this.options();
		return this.options().filter((option) => option.label.toLowerCase().includes(q));
	}, ...ngDevMode ? [{ debugName: "filteredOptions" }] : /* istanbul ignore next */ []);
	selectedChips = computed(() => {
		const selected = this.values();
		return this.options().filter((option) => selected.includes(option.value));
	}, ...ngDevMode ? [{ debugName: "selectedChips" }] : /* istanbul ignore next */ []);
	constructor() {
		registerDismissibleOverlay({
			isOpen: () => this.open(),
			close: () => this.open.set(false),
			isInside: (target) => (this.trigger()?.nativeElement.contains(target) ?? false) || (this.menu()?.nativeElement.contains(target) ?? false)
		});
		const placeMenu = registerAnchoredPopup({
			anchor: () => this.trigger()?.nativeElement,
			popup: () => this.menu()?.nativeElement,
			upClass: "rs-dropdown__menu--up",
			gap: 6,
			matchWidth: true
		});
		afterRenderEffect(() => {
			if (!this.menu()) return;
			placeMenu();
			if (this.focusSearchPending) {
				this.focusSearchPending = false;
				this.searchInput()?.nativeElement.focus();
			}
		});
	}
	toggleOpen() {
		if (this.open()) {
			this.open.set(false);
			return;
		}
		this.query.set("");
		this.focusSearchPending = this.searchable();
		this.open.set(true);
	}
	selectSingle(option) {
		this.value.set(option.value);
		this.open.set(false);
	}
	toggleMulti(option) {
		this.values.update((selected) => selected.includes(option.value) ? selected.filter((value) => value !== option.value) : [...selected, option.value]);
	}
	removeChip(value, event) {
		event.stopPropagation();
		this.values.update((selected) => selected.filter((v) => v !== value));
	}
	onSearchInput(event) {
		this.query.set(event.target.value);
	}
	isSelected(option) {
		return this.multi() ? this.values().includes(option.value) : this.value() === option.value;
	}
	triggerLabel() {
		return this.options().find((option) => option.value === this.value())?.label ?? "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsDropdown,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsDropdown,
		isStandalone: true,
		selector: "rs-dropdown",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			multi: {
				classPropertyName: "multi",
				publicName: "multi",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			searchable: {
				classPropertyName: "searchable",
				publicName: "searchable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			values: {
				classPropertyName: "values",
				publicName: "values",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			values: "valuesChange"
		},
		viewQueries: [
			{
				propertyName: "trigger",
				first: true,
				predicate: ["trigger"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "menu",
				first: true,
				predicate: ["menu"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "searchInput",
				first: true,
				predicate: ["searchInput"],
				descendants: true,
				isSignal: true
			}
		],
		ngImport: i0,
		template: "<div class=\"rs-dropdown\" [class.rs-dropdown--multi]=\"multi()\">\n  <button\n    type=\"button\"\n    class=\"rs-dropdown__trigger\"\n    #trigger\n    aria-haspopup=\"listbox\"\n    [attr.aria-expanded]=\"open()\"\n    (click)=\"toggleOpen()\"\n  >\n    @if (multi()) {\n      <span class=\"rs-dropdown__chips\">\n        @if (selectedChips().length === 0) {\n          <span class=\"rs-dropdown__placeholder\">{{ placeholder() }}</span>\n        }\n        @for (chip of selectedChips(); track chip.value) {\n          <span class=\"rs-chip\">\n            {{ chip.label }}\n            <button\n              type=\"button\"\n              class=\"rs-chip__remove\"\n              aria-label=\"Entfernen\"\n              (click)=\"removeChip(chip.value, $event)\"\n            >\n              ×\n            </button>\n          </span>\n        }\n      </span>\n    } @else {\n      <span class=\"rs-dropdown__value\" [class.rs-dropdown__placeholder]=\"!triggerLabel()\">\n        {{ triggerLabel() || placeholder() }}\n      </span>\n    }\n    <span class=\"rs-dropdown__arrow\"></span>\n  </button>\n\n  @if (open()) {\n    <ul\n      class=\"rs-dropdown__menu\"\n      popover=\"manual\"\n      role=\"listbox\"\n      [attr.aria-multiselectable]=\"multi() || null\"\n      #menu\n    >\n      @if (searchable()) {\n        <li class=\"rs-dropdown__search\">\n          <input\n            class=\"rs-dropdown__search-input\"\n            #searchInput\n            [value]=\"query()\"\n            (input)=\"onSearchInput($event)\"\n          />\n        </li>\n      }\n      @for (option of filteredOptions(); track option.value) {\n        <li\n          class=\"rs-dropdown__option\"\n          role=\"option\"\n          [attr.data-value]=\"option.value\"\n          [attr.aria-selected]=\"isSelected(option)\"\n          (click)=\"multi() ? toggleMulti(option) : selectSingle(option)\"\n        >\n          @if (multi()) {\n            <input type=\"checkbox\" [checked]=\"isSelected(option)\" (click)=\"$event.preventDefault()\" />\n          }\n          {{ option.label }}\n        </li>\n      }\n      @if (filteredOptions().length === 0) {\n        <li class=\"rs-dropdown__empty\">Keine Treffer</li>\n      }\n    </ul>\n  }\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsDropdown,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-dropdown",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"rs-dropdown\" [class.rs-dropdown--multi]=\"multi()\">\n  <button\n    type=\"button\"\n    class=\"rs-dropdown__trigger\"\n    #trigger\n    aria-haspopup=\"listbox\"\n    [attr.aria-expanded]=\"open()\"\n    (click)=\"toggleOpen()\"\n  >\n    @if (multi()) {\n      <span class=\"rs-dropdown__chips\">\n        @if (selectedChips().length === 0) {\n          <span class=\"rs-dropdown__placeholder\">{{ placeholder() }}</span>\n        }\n        @for (chip of selectedChips(); track chip.value) {\n          <span class=\"rs-chip\">\n            {{ chip.label }}\n            <button\n              type=\"button\"\n              class=\"rs-chip__remove\"\n              aria-label=\"Entfernen\"\n              (click)=\"removeChip(chip.value, $event)\"\n            >\n              ×\n            </button>\n          </span>\n        }\n      </span>\n    } @else {\n      <span class=\"rs-dropdown__value\" [class.rs-dropdown__placeholder]=\"!triggerLabel()\">\n        {{ triggerLabel() || placeholder() }}\n      </span>\n    }\n    <span class=\"rs-dropdown__arrow\"></span>\n  </button>\n\n  @if (open()) {\n    <ul\n      class=\"rs-dropdown__menu\"\n      popover=\"manual\"\n      role=\"listbox\"\n      [attr.aria-multiselectable]=\"multi() || null\"\n      #menu\n    >\n      @if (searchable()) {\n        <li class=\"rs-dropdown__search\">\n          <input\n            class=\"rs-dropdown__search-input\"\n            #searchInput\n            [value]=\"query()\"\n            (input)=\"onSearchInput($event)\"\n          />\n        </li>\n      }\n      @for (option of filteredOptions(); track option.value) {\n        <li\n          class=\"rs-dropdown__option\"\n          role=\"option\"\n          [attr.data-value]=\"option.value\"\n          [attr.aria-selected]=\"isSelected(option)\"\n          (click)=\"multi() ? toggleMulti(option) : selectSingle(option)\"\n        >\n          @if (multi()) {\n            <input type=\"checkbox\" [checked]=\"isSelected(option)\" (click)=\"$event.preventDefault()\" />\n          }\n          {{ option.label }}\n        </li>\n      }\n      @if (filteredOptions().length === 0) {\n        <li class=\"rs-dropdown__empty\">Keine Treffer</li>\n      }\n    </ul>\n  }\n</div>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		multi: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "multi",
				required: false
			}]
		}],
		searchable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "searchable",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		values: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "values",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valuesChange"]
		}],
		trigger: [{
			type: i0.ViewChild,
			args: ["trigger", { isSignal: true }]
		}],
		menu: [{
			type: i0.ViewChild,
			args: ["menu", { isSignal: true }]
		}],
		searchInput: [{
			type: i0.ViewChild,
			args: ["searchInput", { isSignal: true }]
		}]
	}
});
const MONTH_NAMES = [
	"Januar",
	"Februar",
	"März",
	"April",
	"Mai",
	"Juni",
	"Juli",
	"August",
	"September",
	"Oktober",
	"November",
	"Dezember"
];
const WEEKDAY_LABELS = [
	"Mo",
	"Di",
	"Mi",
	"Do",
	"Fr",
	"Sa",
	"So"
];
function pad(n) {
	return String(n).padStart(2, "0");
}
var RsDatepicker = class RsDatepicker {
	withTime = input(false, ...ngDevMode ? [{ debugName: "withTime" }] : /* istanbul ignore next */ []);
	placeholder = input("TT.MM.JJJJ", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	minDate = input(null, ...ngDevMode ? [{ debugName: "minDate" }] : /* istanbul ignore next */ []);
	maxDate = input(null, ...ngDevMode ? [{ debugName: "maxDate" }] : /* istanbul ignore next */ []);
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	invalid = input(false, {
		...ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	date = model(null, ...ngDevMode ? [{ debugName: "date" }] : /* istanbul ignore next */ []);
	value = model(null, ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	time = model("12:00", ...ngDevMode ? [{ debugName: "time" }] : /* istanbul ignore next */ []);
	touch = output();
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	viewMonth = signal(startOfMonth(/* @__PURE__ */ new Date()), ...ngDevMode ? [{ debugName: "viewMonth" }] : /* istanbul ignore next */ []);
	activeDate = signal(startOfDay(/* @__PURE__ */ new Date()), ...ngDevMode ? [{ debugName: "activeDate" }] : /* istanbul ignore next */ []);
	weekdayLabels = WEEKDAY_LABELS;
	elementRef = inject(ElementRef);
	calendar = viewChild("calendar", ...ngDevMode ? [{ debugName: "calendar" }] : /* istanbul ignore next */ []);
	inputEl = viewChild.required("input", ...ngDevMode ? [{ debugName: "inputEl" }] : /* istanbul ignore next */ []);
	trigger = null;
	focusRequest = signal(0, ...ngDevMode ? [{ debugName: "focusRequest" }] : /* istanbul ignore next */ []);
	handledFocusRequest = 0;
	selected = linkedSignal({
		...ngDevMode ? { debugName: "selected" } : /* istanbul ignore next */ {},
		source: () => [this.date(), this.value()],
		computation: ([date, value], previous) => {
			if (!previous) return date ?? value;
			return date !== previous.source[0] ? date : value;
		}
	});
	min = computed(() => dayOrNull(this.minDate()), ...ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []);
	max = computed(() => dayOrNull(this.maxDate()), ...ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []);
	canPrev = computed(() => {
		const min = this.min();
		return !min || this.viewMonth() > startOfMonth(min);
	}, ...ngDevMode ? [{ debugName: "canPrev" }] : /* istanbul ignore next */ []);
	canNext = computed(() => {
		const max = this.max();
		return !max || this.viewMonth() < startOfMonth(max);
	}, ...ngDevMode ? [{ debugName: "canNext" }] : /* istanbul ignore next */ []);
	title = computed(() => `${MONTH_NAMES[this.viewMonth().getMonth()]} ${this.viewMonth().getFullYear()}`, ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	leadingBlanks = computed(() => weekdayIndex(this.viewMonth()), ...ngDevMode ? [{ debugName: "leadingBlanks" }] : /* istanbul ignore next */ []);
	blanks = computed(() => Array.from({ length: this.leadingBlanks() }), ...ngDevMode ? [{ debugName: "blanks" }] : /* istanbul ignore next */ []);
	dayNumbers = computed(() => {
		const daysInMonth = new Date(this.viewMonth().getFullYear(), this.viewMonth().getMonth() + 1, 0).getDate();
		return Array.from({ length: daysInMonth }, (_, i) => i + 1);
	}, ...ngDevMode ? [{ debugName: "dayNumbers" }] : /* istanbul ignore next */ []);
	tabStopDay = computed(() => {
		const active = this.activeDate();
		if (isSameMonth(active, this.viewMonth()) && this.isAllowed(active)) return active.getDate();
		return this.dayNumbers().find((day) => this.isAllowed(this.dateFor(day))) ?? null;
	}, ...ngDevMode ? [{ debugName: "tabStopDay" }] : /* istanbul ignore next */ []);
	formattedValue = computed(() => {
		const selected = this.selected();
		if (!selected) return "";
		const datePart = `${pad(selected.getDate())}.${pad(selected.getMonth() + 1)}.${selected.getFullYear()}`;
		return this.withTime() ? `${datePart}, ${this.time()}` : datePart;
	}, ...ngDevMode ? [{ debugName: "formattedValue" }] : /* istanbul ignore next */ []);
	constructor() {
		registerDismissibleOverlay({
			isOpen: () => this.open(),
			close: () => this.open.set(false),
			isInside: (target) => this.elementRef.nativeElement.contains(target)
		});
		const placeCalendar = registerAnchoredPopup({
			anchor: () => this.inputEl().nativeElement,
			popup: () => this.calendar()?.nativeElement,
			upClass: "rs-calendar--up",
			gap: 8
		});
		afterRenderEffect(() => {
			const calendarEl = this.calendar()?.nativeElement;
			const request = this.focusRequest();
			if (!calendarEl) return;
			placeCalendar();
			if (request === this.handledFocusRequest) return;
			this.handledFocusRequest = request;
			calendarEl.querySelector(".rs-calendar__day[tabindex=\"0\"]")?.focus();
		});
	}
	clear() {
		this.date.set(null);
		this.value.set(null);
	}
	toggleOpen(trigger) {
		if (this.open()) this.close(false);
		else this.openCalendar(trigger);
	}
	onInputKeydown(event) {
		if (event.key !== "Enter" && event.key !== " " && event.key !== "ArrowDown") return;
		event.preventDefault();
		if (this.open()) this.focusRequest.update((n) => n + 1);
		else this.openCalendar(event.target);
	}
	onEscape(event) {
		if (!this.open()) return;
		event.stopPropagation();
		this.close(true);
	}
	onFocusOut(event) {
		const next = event.relatedTarget;
		if (next instanceof Node && this.elementRef.nativeElement.contains(next)) return;
		this.open.set(false);
		this.touch.emit();
	}
	onGridKeydown(event) {
		const active = this.activeDate();
		let next;
		switch (event.key) {
			case "ArrowLeft":
				next = addDays(active, -1);
				break;
			case "ArrowRight":
				next = addDays(active, 1);
				break;
			case "ArrowUp":
				next = addDays(active, -7);
				break;
			case "ArrowDown":
				next = addDays(active, 7);
				break;
			case "Home":
				next = addDays(active, -weekdayIndex(active));
				break;
			case "End":
				next = addDays(active, 6 - weekdayIndex(active));
				break;
			case "PageUp":
				next = addMonthsKeepingDay(active, event.shiftKey ? -12 : -1);
				break;
			case "PageDown":
				next = addMonthsKeepingDay(active, event.shiftKey ? 12 : 1);
				break;
			default: return;
		}
		event.preventDefault();
		const target = this.clamp(next);
		this.activeDate.set(target);
		this.viewMonth.set(startOfMonth(target));
		this.focusRequest.update((n) => n + 1);
	}
	onDayFocus(day) {
		this.activeDate.set(this.dateFor(day));
	}
	prevMonth() {
		if (this.canPrev()) this.viewMonth.update((view) => addMonths(view, -1));
	}
	nextMonth() {
		if (this.canNext()) this.viewMonth.update((view) => addMonths(view, 1));
	}
	selectDay(day) {
		const date = this.dateFor(day);
		if (!this.isAllowed(date)) return;
		this.activeDate.set(date);
		this.date.set(date);
		this.value.set(date);
		if (!this.withTime()) this.close(true);
	}
	onTimeChange(event) {
		this.time.set(event.target.value);
	}
	isToday(day) {
		return this.dateFor(day).toDateString() === (/* @__PURE__ */ new Date()).toDateString();
	}
	isSelected(day) {
		const selected = this.selected();
		return !!selected && this.dateFor(day).toDateString() === selected.toDateString();
	}
	isAllowedDay(day) {
		return this.isAllowed(this.dateFor(day));
	}
	openCalendar(trigger) {
		if (this.disabled()) return;
		this.trigger = trigger;
		const target = this.clamp(startOfDay(this.selected() ?? /* @__PURE__ */ new Date()));
		this.activeDate.set(target);
		this.viewMonth.set(startOfMonth(target));
		this.focusRequest.update((n) => n + 1);
		this.open.set(true);
	}
	close(returnFocus) {
		if (returnFocus) (this.trigger ?? this.inputEl().nativeElement).focus();
		this.open.set(false);
	}
	isAllowed(date) {
		const min = this.min();
		const max = this.max();
		return (!min || date >= min) && (!max || date <= max);
	}
	clamp(date) {
		const min = this.min();
		const max = this.max();
		if (min && date < min) return min;
		if (max && date > max) return max;
		return date;
	}
	dateFor(day) {
		return new Date(this.viewMonth().getFullYear(), this.viewMonth().getMonth(), day);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsDatepicker,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsDatepicker,
		isStandalone: true,
		selector: "rs-datepicker",
		inputs: {
			withTime: {
				classPropertyName: "withTime",
				publicName: "withTime",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minDate: {
				classPropertyName: "minDate",
				publicName: "minDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxDate: {
				classPropertyName: "maxDate",
				publicName: "maxDate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			invalid: {
				classPropertyName: "invalid",
				publicName: "invalid",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			date: {
				classPropertyName: "date",
				publicName: "date",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			time: {
				classPropertyName: "time",
				publicName: "time",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			date: "dateChange",
			value: "valueChange",
			time: "timeChange",
			touch: "touch"
		},
		viewQueries: [{
			propertyName: "calendar",
			first: true,
			predicate: ["calendar"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "inputEl",
			first: true,
			predicate: ["input"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div\n  class=\"rs-datepicker\"\n  [class.rs-datepicker--invalid]=\"invalid()\"\n  (keydown.escape)=\"onEscape($event)\"\n  (focusout)=\"onFocusOut($event)\"\n>\n  <input\n    #input\n    class=\"rs-input\"\n    type=\"text\"\n    readonly\n    [placeholder]=\"placeholder()\"\n    [value]=\"formattedValue()\"\n    [disabled]=\"disabled()\"\n    (click)=\"toggleOpen(input)\"\n    (keydown)=\"onInputKeydown($event)\"\n  />\n  <button\n    #toggle\n    type=\"button\"\n    class=\"rs-datepicker__toggle\"\n    aria-label=\"Kalender öffnen\"\n    [disabled]=\"disabled()\"\n    (click)=\"toggleOpen(toggle)\"\n  >\n    📅\n  </button>\n\n  @if (open()) {\n    <div class=\"rs-calendar\" popover=\"manual\" #calendar>\n      <div class=\"rs-calendar__header\">\n        <button\n          type=\"button\"\n          class=\"rs-calendar__nav\"\n          aria-label=\"Vorheriger Monat\"\n          [disabled]=\"!canPrev()\"\n          (click)=\"prevMonth()\"\n        >\n          ‹\n        </button>\n        <span class=\"rs-calendar__title\">{{ title() }}</span>\n        <button\n          type=\"button\"\n          class=\"rs-calendar__nav\"\n          aria-label=\"Nächster Monat\"\n          [disabled]=\"!canNext()\"\n          (click)=\"nextMonth()\"\n        >\n          ›\n        </button>\n      </div>\n      <div class=\"rs-calendar__grid\" (keydown)=\"onGridKeydown($event)\">\n        @for (w of weekdayLabels; track w) {\n          <div class=\"rs-calendar__weekday\">{{ w }}</div>\n        }\n        @for (b of blanks(); track $index) {\n          <div></div>\n        }\n        @for (day of dayNumbers(); track day) {\n          <button\n            type=\"button\"\n            class=\"rs-calendar__day\"\n            [class.rs-calendar__day--today]=\"isToday(day)\"\n            [class.rs-calendar__day--selected]=\"isSelected(day)\"\n            [disabled]=\"!isAllowedDay(day)\"\n            [attr.tabindex]=\"day === tabStopDay() ? 0 : -1\"\n            (focus)=\"onDayFocus(day)\"\n            (click)=\"selectDay(day)\"\n          >\n            {{ day }}\n          </button>\n        }\n      </div>\n      @if (withTime()) {\n        <div class=\"rs-calendar__time\">\n          <span class=\"rs-calendar__time-label\">Uhrzeit</span>\n          <input type=\"time\" [value]=\"time()\" (change)=\"onTimeChange($event)\" />\n        </div>\n      }\n    </div>\n  }\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsDatepicker,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-datepicker",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div\n  class=\"rs-datepicker\"\n  [class.rs-datepicker--invalid]=\"invalid()\"\n  (keydown.escape)=\"onEscape($event)\"\n  (focusout)=\"onFocusOut($event)\"\n>\n  <input\n    #input\n    class=\"rs-input\"\n    type=\"text\"\n    readonly\n    [placeholder]=\"placeholder()\"\n    [value]=\"formattedValue()\"\n    [disabled]=\"disabled()\"\n    (click)=\"toggleOpen(input)\"\n    (keydown)=\"onInputKeydown($event)\"\n  />\n  <button\n    #toggle\n    type=\"button\"\n    class=\"rs-datepicker__toggle\"\n    aria-label=\"Kalender öffnen\"\n    [disabled]=\"disabled()\"\n    (click)=\"toggleOpen(toggle)\"\n  >\n    📅\n  </button>\n\n  @if (open()) {\n    <div class=\"rs-calendar\" popover=\"manual\" #calendar>\n      <div class=\"rs-calendar__header\">\n        <button\n          type=\"button\"\n          class=\"rs-calendar__nav\"\n          aria-label=\"Vorheriger Monat\"\n          [disabled]=\"!canPrev()\"\n          (click)=\"prevMonth()\"\n        >\n          ‹\n        </button>\n        <span class=\"rs-calendar__title\">{{ title() }}</span>\n        <button\n          type=\"button\"\n          class=\"rs-calendar__nav\"\n          aria-label=\"Nächster Monat\"\n          [disabled]=\"!canNext()\"\n          (click)=\"nextMonth()\"\n        >\n          ›\n        </button>\n      </div>\n      <div class=\"rs-calendar__grid\" (keydown)=\"onGridKeydown($event)\">\n        @for (w of weekdayLabels; track w) {\n          <div class=\"rs-calendar__weekday\">{{ w }}</div>\n        }\n        @for (b of blanks(); track $index) {\n          <div></div>\n        }\n        @for (day of dayNumbers(); track day) {\n          <button\n            type=\"button\"\n            class=\"rs-calendar__day\"\n            [class.rs-calendar__day--today]=\"isToday(day)\"\n            [class.rs-calendar__day--selected]=\"isSelected(day)\"\n            [disabled]=\"!isAllowedDay(day)\"\n            [attr.tabindex]=\"day === tabStopDay() ? 0 : -1\"\n            (focus)=\"onDayFocus(day)\"\n            (click)=\"selectDay(day)\"\n          >\n            {{ day }}\n          </button>\n        }\n      </div>\n      @if (withTime()) {\n        <div class=\"rs-calendar__time\">\n          <span class=\"rs-calendar__time-label\">Uhrzeit</span>\n          <input type=\"time\" [value]=\"time()\" (change)=\"onTimeChange($event)\" />\n        </div>\n      }\n    </div>\n  }\n</div>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		withTime: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "withTime",
				required: false
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		minDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minDate",
				required: false
			}]
		}],
		maxDate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxDate",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		invalid: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "invalid",
				required: false
			}]
		}],
		date: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "date",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["dateChange"]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		time: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "time",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["timeChange"]
		}],
		touch: [{
			type: i0.Output,
			args: ["touch"]
		}],
		calendar: [{
			type: i0.ViewChild,
			args: ["calendar", { isSignal: true }]
		}],
		inputEl: [{
			type: i0.ViewChild,
			args: ["input", { isSignal: true }]
		}]
	}
});
function startOfDay(date) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}
function dayOrNull(date) {
	return date ? startOfDay(date) : null;
}
function startOfMonth(date) {
	return new Date(date.getFullYear(), date.getMonth(), 1);
}
function addMonths(date, delta) {
	return new Date(date.getFullYear(), date.getMonth() + delta, 1);
}
function addDays(date, delta) {
	return new Date(date.getFullYear(), date.getMonth(), date.getDate() + delta);
}
function addMonthsKeepingDay(date, delta) {
	const target = new Date(date.getFullYear(), date.getMonth() + delta, 1);
	const daysInTarget = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
	return new Date(target.getFullYear(), target.getMonth(), Math.min(date.getDate(), daysInTarget));
}
function weekdayIndex(date) {
	return (date.getDay() + 6) % 7;
}
function isSameMonth(a, b) {
	return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth();
}
var RsList = class RsList {
	values = model([], ...ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []);
	emptyLabel = input("Noch keine Einträge.", ...ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []);
	add(value) {
		this.values.update((values) => [...values, value]);
	}
	removeAt(index) {
		this.values.update((values) => values.filter((_, i) => i !== index));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsList,
		isStandalone: true,
		selector: "rs-list",
		inputs: {
			values: {
				classPropertyName: "values",
				publicName: "values",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			emptyLabel: {
				classPropertyName: "emptyLabel",
				publicName: "emptyLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { values: "valuesChange" },
		ngImport: i0,
		template: "<div class=\"rs-list\">\n  <ul class=\"rs-list__items\">\n    @if (values().length === 0) {\n      <li class=\"rs-list__empty\">{{ emptyLabel() }}</li>\n    }\n    @for (value of values(); track $index) {\n      <li class=\"rs-list__item\">\n        <span class=\"rs-list__item-label\">{{ value }}</span>\n        <button\n          type=\"button\"\n          class=\"rs-list__item-remove\"\n          aria-label=\"Entfernen\"\n          (click)=\"removeAt($index)\"\n        >\n          ×\n        </button>\n      </li>\n    }\n  </ul>\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsList,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-list",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"rs-list\">\n  <ul class=\"rs-list__items\">\n    @if (values().length === 0) {\n      <li class=\"rs-list__empty\">{{ emptyLabel() }}</li>\n    }\n    @for (value of values(); track $index) {\n      <li class=\"rs-list__item\">\n        <span class=\"rs-list__item-label\">{{ value }}</span>\n        <button\n          type=\"button\"\n          class=\"rs-list__item-remove\"\n          aria-label=\"Entfernen\"\n          (click)=\"removeAt($index)\"\n        >\n          ×\n        </button>\n      </li>\n    }\n  </ul>\n</div>\n"
		}]
	}],
	propDecorators: {
		values: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "values",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["valuesChange"]
		}],
		emptyLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "emptyLabel",
				required: false
			}]
		}]
	}
});
const MAX_MATCHES = 8;
var RsAutocomplete = class RsAutocomplete {
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	placeholder = input("", ...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	query = model("", ...ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []);
	commit = output();
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	activeIndex = signal(-1, ...ngDevMode ? [{ debugName: "activeIndex" }] : /* istanbul ignore next */ []);
	elementRef = inject(ElementRef);
	inputEl = viewChild.required("input", ...ngDevMode ? [{ debugName: "inputEl" }] : /* istanbul ignore next */ []);
	menu = viewChild("menu", ...ngDevMode ? [{ debugName: "menu" }] : /* istanbul ignore next */ []);
	filteredOptions = computed(() => {
		const q = this.query().trim().toLowerCase();
		if (!q) return [];
		return this.options().filter((label) => label.toLowerCase().includes(q)).slice(0, MAX_MATCHES);
	}, ...ngDevMode ? [{ debugName: "filteredOptions" }] : /* istanbul ignore next */ []);
	constructor() {
		registerDismissibleOverlay({
			isOpen: () => this.open(),
			close: () => this.open.set(false),
			isInside: (target) => this.elementRef.nativeElement.contains(target)
		});
		const placeMenu = registerAnchoredPopup({
			anchor: () => this.inputEl().nativeElement,
			popup: () => this.menu()?.nativeElement,
			upClass: "rs-dropdown__menu--up",
			gap: 6,
			matchWidth: true
		});
		afterRenderEffect(() => {
			if (this.menu()) placeMenu();
		});
	}
	onInput(event) {
		const value = event.target.value;
		this.query.set(value);
		this.activeIndex.set(-1);
		this.open.set(value.trim().length > 0);
	}
	onFocus() {
		if (this.query().trim().length > 0) this.open.set(true);
	}
	onKeydown(event) {
		if (event.key === "Enter") {
			event.preventDefault();
			const options = this.filteredOptions();
			const active = this.activeIndex();
			if (active >= 0 && active < options.length) this.commitValue(options[active]);
			else if (this.query().trim()) this.commitValue(this.query().trim());
			return;
		}
		if (event.key === "Escape") {
			this.open.set(false);
			return;
		}
		const count = this.filteredOptions().length;
		if (!this.open() || count === 0) return;
		if (event.key === "ArrowDown") {
			event.preventDefault();
			this.activeIndex.update((i) => (i + 1) % count);
		} else if (event.key === "ArrowUp") {
			event.preventDefault();
			this.activeIndex.update((i) => (i - 1 + count) % count);
		}
	}
	selectOption(option) {
		this.commitValue(option);
	}
	highlightParts(label) {
		const q = this.query().trim();
		if (!q) return {
			before: label,
			match: "",
			after: ""
		};
		const index = label.toLowerCase().indexOf(q.toLowerCase());
		if (index === -1) return {
			before: label,
			match: "",
			after: ""
		};
		return {
			before: label.slice(0, index),
			match: label.slice(index, index + q.length),
			after: label.slice(index + q.length)
		};
	}
	commitValue(value) {
		this.commit.emit(value);
		this.query.set("");
		this.open.set(false);
		this.activeIndex.set(-1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsAutocomplete,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsAutocomplete,
		isStandalone: true,
		selector: "rs-autocomplete",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			query: {
				classPropertyName: "query",
				publicName: "query",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			query: "queryChange",
			commit: "commit"
		},
		viewQueries: [{
			propertyName: "inputEl",
			first: true,
			predicate: ["input"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "menu",
			first: true,
			predicate: ["menu"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div class=\"rs-autocomplete\">\n  <input\n    #input\n    class=\"rs-input\"\n    type=\"text\"\n    role=\"combobox\"\n    aria-autocomplete=\"list\"\n    [attr.aria-expanded]=\"open()\"\n    autocomplete=\"off\"\n    [placeholder]=\"placeholder()\"\n    [value]=\"query()\"\n    (input)=\"onInput($event)\"\n    (focus)=\"onFocus()\"\n    (keydown)=\"onKeydown($event)\"\n  />\n  @if (open()) {\n    <ul class=\"rs-dropdown__menu rs-autocomplete__menu\" popover=\"manual\" role=\"listbox\" #menu>\n      @for (option of filteredOptions(); track option; let i = $index) {\n        @let parts = highlightParts(option);\n        <li\n          class=\"rs-dropdown__option rs-autocomplete__option\"\n          [class.rs-autocomplete__option--active]=\"i === activeIndex()\"\n          role=\"option\"\n          (click)=\"selectOption(option)\"\n        >\n          {{ parts.before }}<mark>{{ parts.match }}</mark>{{ parts.after }}\n        </li>\n      }\n      @if (filteredOptions().length === 0) {\n        <li class=\"rs-dropdown__empty\">Keine Treffer</li>\n      }\n    </ul>\n  }\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsAutocomplete,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-autocomplete",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"rs-autocomplete\">\n  <input\n    #input\n    class=\"rs-input\"\n    type=\"text\"\n    role=\"combobox\"\n    aria-autocomplete=\"list\"\n    [attr.aria-expanded]=\"open()\"\n    autocomplete=\"off\"\n    [placeholder]=\"placeholder()\"\n    [value]=\"query()\"\n    (input)=\"onInput($event)\"\n    (focus)=\"onFocus()\"\n    (keydown)=\"onKeydown($event)\"\n  />\n  @if (open()) {\n    <ul class=\"rs-dropdown__menu rs-autocomplete__menu\" popover=\"manual\" role=\"listbox\" #menu>\n      @for (option of filteredOptions(); track option; let i = $index) {\n        @let parts = highlightParts(option);\n        <li\n          class=\"rs-dropdown__option rs-autocomplete__option\"\n          [class.rs-autocomplete__option--active]=\"i === activeIndex()\"\n          role=\"option\"\n          (click)=\"selectOption(option)\"\n        >\n          {{ parts.before }}<mark>{{ parts.match }}</mark>{{ parts.after }}\n        </li>\n      }\n      @if (filteredOptions().length === 0) {\n        <li class=\"rs-dropdown__empty\">Keine Treffer</li>\n      }\n    </ul>\n  }\n</div>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: false
			}]
		}],
		query: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "query",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["queryChange"]
		}],
		commit: [{
			type: i0.Output,
			args: ["commit"]
		}],
		inputEl: [{
			type: i0.ViewChild,
			args: ["input", { isSignal: true }]
		}],
		menu: [{
			type: i0.ViewChild,
			args: ["menu", { isSignal: true }]
		}]
	}
});
var RsWizardPage = class RsWizardPage {
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	description = input("", ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	canProceed = input(true, ...ngDevMode ? [{ debugName: "canProceed" }] : /* istanbul ignore next */ []);
	validate = input(null, ...ngDevMode ? [{ debugName: "validate" }] : /* istanbul ignore next */ []);
	errorMessage = input("", ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	active = signal(false, ...ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []);
	showError = signal(false, ...ngDevMode ? [{ debugName: "showError" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsWizardPage,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsWizardPage,
		isStandalone: true,
		selector: "rs-wizard-page",
		inputs: {
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canProceed: {
				classPropertyName: "canProceed",
				publicName: "canProceed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			validate: {
				classPropertyName: "validate",
				publicName: "validate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			errorMessage: {
				classPropertyName: "errorMessage",
				publicName: "errorMessage",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: "<div class=\"rs-wizard__page\" [hidden]=\"!active()\">\n  <h3 class=\"rs-wizard__page-title\">{{ title() }}</h3>\n  @if (description()) {\n    <p class=\"rs-wizard__page-desc\">{{ description() }}</p>\n  }\n  <ng-content />\n  @if (showError() && errorMessage()) {\n    <p class=\"rs-wizard__page-desc\" style=\"color: var(--rs-red)\">{{ errorMessage() }}</p>\n  }\n</div>\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsWizardPage,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-wizard-page",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div class=\"rs-wizard__page\" [hidden]=\"!active()\">\n  <h3 class=\"rs-wizard__page-title\">{{ title() }}</h3>\n  @if (description()) {\n    <p class=\"rs-wizard__page-desc\">{{ description() }}</p>\n  }\n  <ng-content />\n  @if (showError() && errorMessage()) {\n    <p class=\"rs-wizard__page-desc\" style=\"color: var(--rs-red)\">{{ errorMessage() }}</p>\n  }\n</div>\n"
		}]
	}],
	propDecorators: {
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		canProceed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canProceed",
				required: false
			}]
		}],
		validate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validate",
				required: false
			}]
		}],
		errorMessage: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "errorMessage",
				required: false
			}]
		}]
	}
});
var RsWizard = class RsWizard {
	open = model(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	title = input("", ...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	size = input("xl", ...ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []);
	horizontal = input(false, ...ngDevMode ? [{ debugName: "horizontal" }] : /* istanbul ignore next */ []);
	currentIndex = signal(0, ...ngDevMode ? [{ debugName: "currentIndex" }] : /* istanbul ignore next */ []);
	unlockedIndex = signal(0, ...ngDevMode ? [{ debugName: "unlockedIndex" }] : /* istanbul ignore next */ []);
	pages = contentChildren(RsWizardPage, ...ngDevMode ? [{ debugName: "pages" }] : /* istanbul ignore next */ []);
	isLastPage = computed(() => this.currentIndex() === this.pages().length - 1, ...ngDevMode ? [{ debugName: "isLastPage" }] : /* istanbul ignore next */ []);
	constructor() {
		registerDismissibleOverlay({
			isOpen: () => this.open(),
			close: () => this.close(),
			isInside: () => true,
			closeOnOutsideClick: false
		});
		effect(() => {
			const idx = this.currentIndex();
			for (const [i, page] of this.pages().entries()) page.active.set(i === idx);
		});
		effect(() => {
			if (this.open()) {
				this.currentIndex.set(0);
				this.unlockedIndex.set(0);
				for (const page of this.pages()) page.showError.set(false);
			}
		});
	}
	close() {
		this.open.set(false);
	}
	goTo(index) {
		if (index <= this.unlockedIndex()) this.currentIndex.set(index);
	}
	back() {
		if (this.currentIndex() > 0) this.currentIndex.update((i) => i - 1);
	}
	next() {
		const page = this.pages()[this.currentIndex()];
		if (!page) return;
		const validate = page.validate();
		const valid = validate ? validate() : true;
		page.showError.set(!valid);
		if (!valid) return;
		const nextIndex = this.currentIndex() + 1;
		this.unlockedIndex.update((u) => Math.max(u, nextIndex));
		this.currentIndex.set(nextIndex);
	}
	finish() {
		this.close();
	}
	currentCanProceed() {
		return this.pages()[this.currentIndex()]?.canProceed() ?? true;
	}
	stepHasError(index) {
		return index === this.currentIndex() && (this.pages()[index]?.showError() ?? false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsWizard,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsWizard,
		isStandalone: true,
		selector: "rs-wizard",
		inputs: {
			open: {
				classPropertyName: "open",
				publicName: "open",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			size: {
				classPropertyName: "size",
				publicName: "size",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			horizontal: {
				classPropertyName: "horizontal",
				publicName: "horizontal",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { open: "openChange" },
		queries: [{
			propertyName: "pages",
			predicate: RsWizardPage,
			isSignal: true
		}],
		ngImport: i0,
		template: "@if (open()) {\n  <div class=\"rs-modal-overlay\">\n    <div\n      class=\"rs-wizard\"\n      [class.rs-wizard--md]=\"size() === 'md'\"\n      [class.rs-wizard--lg]=\"size() === 'lg'\"\n      [class.rs-wizard--full]=\"size() === 'full'\"\n      [class.rs-wizard--horizontal]=\"horizontal()\"\n    >\n      <div class=\"rs-wizard__head\">\n        <span class=\"rs-wizard__title\">{{ title() }}</span>\n        <button type=\"button\" class=\"rs-wizard__close\" (click)=\"close()\">✕</button>\n      </div>\n      <div class=\"rs-wizard__body\">\n        <nav class=\"rs-wizard__stepnav\">\n          @for (page of pages(); track page; let i = $index) {\n            <button\n              type=\"button\"\n              class=\"rs-wizard__step\"\n              [class.rs-wizard__step--current]=\"i === currentIndex()\"\n              [class.rs-wizard__step--done]=\"i < currentIndex()\"\n              [class.rs-wizard__step--error]=\"stepHasError(i)\"\n              [disabled]=\"i > unlockedIndex()\"\n              (click)=\"goTo(i)\"\n            >\n              <span class=\"rs-wizard__step-num\">{{ i + 1 }}</span>\n              <span class=\"rs-wizard__step-title\">{{ page.title() }}</span>\n            </button>\n          }\n        </nav>\n        <div class=\"rs-wizard__content\">\n          <ng-content />\n        </div>\n      </div>\n      <div class=\"rs-wizard__footer\">\n        <button type=\"button\" class=\"rs-btn rs-btn--outline rs-btn--grey\" (click)=\"close()\">\n          Abbrechen\n        </button>\n        <div class=\"rs-wizard__footer-nav\">\n          @if (currentIndex() > 0) {\n            <button type=\"button\" class=\"rs-btn rs-btn--outline rs-btn--green\" (click)=\"back()\">\n              Zurück\n            </button>\n          }\n          @if (!isLastPage()) {\n            <button\n              type=\"button\"\n              class=\"rs-btn rs-btn--filled rs-btn--green\"\n              [disabled]=\"!currentCanProceed()\"\n              (click)=\"next()\"\n            >\n              Weiter\n            </button>\n          } @else {\n            <button type=\"button\" class=\"rs-btn rs-btn--filled rs-btn--green\" (click)=\"finish()\">\n              Abschließen\n            </button>\n          }\n        </div>\n      </div>\n    </div>\n  </div>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsWizard,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-wizard",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "@if (open()) {\n  <div class=\"rs-modal-overlay\">\n    <div\n      class=\"rs-wizard\"\n      [class.rs-wizard--md]=\"size() === 'md'\"\n      [class.rs-wizard--lg]=\"size() === 'lg'\"\n      [class.rs-wizard--full]=\"size() === 'full'\"\n      [class.rs-wizard--horizontal]=\"horizontal()\"\n    >\n      <div class=\"rs-wizard__head\">\n        <span class=\"rs-wizard__title\">{{ title() }}</span>\n        <button type=\"button\" class=\"rs-wizard__close\" (click)=\"close()\">✕</button>\n      </div>\n      <div class=\"rs-wizard__body\">\n        <nav class=\"rs-wizard__stepnav\">\n          @for (page of pages(); track page; let i = $index) {\n            <button\n              type=\"button\"\n              class=\"rs-wizard__step\"\n              [class.rs-wizard__step--current]=\"i === currentIndex()\"\n              [class.rs-wizard__step--done]=\"i < currentIndex()\"\n              [class.rs-wizard__step--error]=\"stepHasError(i)\"\n              [disabled]=\"i > unlockedIndex()\"\n              (click)=\"goTo(i)\"\n            >\n              <span class=\"rs-wizard__step-num\">{{ i + 1 }}</span>\n              <span class=\"rs-wizard__step-title\">{{ page.title() }}</span>\n            </button>\n          }\n        </nav>\n        <div class=\"rs-wizard__content\">\n          <ng-content />\n        </div>\n      </div>\n      <div class=\"rs-wizard__footer\">\n        <button type=\"button\" class=\"rs-btn rs-btn--outline rs-btn--grey\" (click)=\"close()\">\n          Abbrechen\n        </button>\n        <div class=\"rs-wizard__footer-nav\">\n          @if (currentIndex() > 0) {\n            <button type=\"button\" class=\"rs-btn rs-btn--outline rs-btn--green\" (click)=\"back()\">\n              Zurück\n            </button>\n          }\n          @if (!isLastPage()) {\n            <button\n              type=\"button\"\n              class=\"rs-btn rs-btn--filled rs-btn--green\"\n              [disabled]=\"!currentCanProceed()\"\n              (click)=\"next()\"\n            >\n              Weiter\n            </button>\n          } @else {\n            <button type=\"button\" class=\"rs-btn rs-btn--filled rs-btn--green\" (click)=\"finish()\">\n              Abschließen\n            </button>\n          }\n        </div>\n      </div>\n    </div>\n  </div>\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		open: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "open",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["openChange"]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: false
			}]
		}],
		size: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "size",
				required: false
			}]
		}],
		horizontal: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "horizontal",
				required: false
			}]
		}],
		pages: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => RsWizardPage), { isSignal: true }]
		}]
	}
});
var RsCellDef = class RsCellDef {
	templateRef = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsCellDef,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: RsCellDef,
		isStandalone: true,
		selector: "ng-template[rsCellDef]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsCellDef,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[rsCellDef]" }]
	}]
});
var RsFilterDef = class RsFilterDef {
	templateRef = inject(TemplateRef);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsFilterDef,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: RsFilterDef,
		isStandalone: true,
		selector: "ng-template[rsFilterDef]",
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsFilterDef,
	decorators: [{
		type: Directive,
		args: [{ selector: "ng-template[rsFilterDef]" }]
	}]
});
var RsTableColumn = class RsTableColumn {
	key = input.required(...ngDevMode ? [{ debugName: "key" }] : /* istanbul ignore next */ []);
	header = input("", ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	width = input(160, ...ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []);
	minWidth = input(60, ...ngDevMode ? [{ debugName: "minWidth" }] : /* istanbul ignore next */ []);
	resizable = input(true, ...ngDevMode ? [{ debugName: "resizable" }] : /* istanbul ignore next */ []);
	sortable = input(false, ...ngDevMode ? [{ debugName: "sortable" }] : /* istanbul ignore next */ []);
	filterType = input(null, ...ngDevMode ? [{ debugName: "filterType" }] : /* istanbul ignore next */ []);
	flex = input(null, ...ngDevMode ? [{ debugName: "flex" }] : /* istanbul ignore next */ []);
	align = input("start", ...ngDevMode ? [{ debugName: "align" }] : /* istanbul ignore next */ []);
	wrap = input(false, {
		...ngDevMode ? { debugName: "wrap" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	maxLines = input(null, ...ngDevMode ? [{ debugName: "maxLines" }] : /* istanbul ignore next */ []);
	cellDef = contentChild(RsCellDef, ...ngDevMode ? [{ debugName: "cellDef" }] : /* istanbul ignore next */ []);
	filterDef = contentChild(RsFilterDef, ...ngDevMode ? [{ debugName: "filterDef" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsTableColumn,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.0",
		type: RsTableColumn,
		isStandalone: true,
		selector: "rs-table-column",
		inputs: {
			key: {
				classPropertyName: "key",
				publicName: "key",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			width: {
				classPropertyName: "width",
				publicName: "width",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			minWidth: {
				classPropertyName: "minWidth",
				publicName: "minWidth",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			resizable: {
				classPropertyName: "resizable",
				publicName: "resizable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			sortable: {
				classPropertyName: "sortable",
				publicName: "sortable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterType: {
				classPropertyName: "filterType",
				publicName: "filterType",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			flex: {
				classPropertyName: "flex",
				publicName: "flex",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			align: {
				classPropertyName: "align",
				publicName: "align",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			wrap: {
				classPropertyName: "wrap",
				publicName: "wrap",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			maxLines: {
				classPropertyName: "maxLines",
				publicName: "maxLines",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		queries: [{
			propertyName: "cellDef",
			first: true,
			predicate: RsCellDef,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "filterDef",
			first: true,
			predicate: RsFilterDef,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsTableColumn,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-table-column",
			template: "",
			changeDetection: ChangeDetectionStrategy.OnPush
		}]
	}],
	propDecorators: {
		key: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "key",
				required: true
			}]
		}],
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		width: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "width",
				required: false
			}]
		}],
		minWidth: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minWidth",
				required: false
			}]
		}],
		resizable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "resizable",
				required: false
			}]
		}],
		sortable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "sortable",
				required: false
			}]
		}],
		filterType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterType",
				required: false
			}]
		}],
		flex: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "flex",
				required: false
			}]
		}],
		align: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "align",
				required: false
			}]
		}],
		wrap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "wrap",
				required: false
			}]
		}],
		maxLines: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "maxLines",
				required: false
			}]
		}],
		cellDef: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => RsCellDef), { isSignal: true }]
		}],
		filterDef: [{
			type: i0.ContentChild,
			args: [i0.forwardRef(() => RsFilterDef), { isSignal: true }]
		}]
	}
});
var RsTableText = class RsTableText {
	element = inject(ElementRef);
	updateTitle() {
		const el = this.element.nativeElement;
		const text = el.textContent?.trim() ?? "";
		if ((el.scrollWidth > el.clientWidth || el.scrollHeight - el.clientHeight > 1) && text !== "") el.title = text;
		else el.removeAttribute("title");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsTableText,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.0",
		type: RsTableText,
		isStandalone: true,
		selector: "[rsTableText]",
		host: {
			listeners: { "mouseenter": "updateTitle()" },
			classAttribute: "rs-table__text"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsTableText,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[rsTableText]",
			host: {
				class: "rs-table__text",
				"(mouseenter)": "updateTitle()"
			}
		}]
	}]
});
const DEFAULT_PAGE_SIZE_OPTIONS = [
	5,
	10,
	20,
	50
];
var RsTable = class RsTable {
	fetchData = input(void 0, ...ngDevMode ? [{ debugName: "fetchData" }] : /* istanbul ignore next */ []);
	data = input(void 0, ...ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []);
	mode = input("pager", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	pageSizeOptions = input(DEFAULT_PAGE_SIZE_OPTIONS, ...ngDevMode ? [{ debugName: "pageSizeOptions" }] : /* istanbul ignore next */ []);
	initialPageSize = input(void 0, {
		...ngDevMode ? { debugName: "initialPageSize" } : /* istanbul ignore next */ {},
		alias: "pageSize"
	});
	rowClass = input(null, ...ngDevMode ? [{ debugName: "rowClass" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	columns = contentChildren(RsTableColumn, ...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	scrollEl = viewChild.required("scroll", ...ngDevMode ? [{ debugName: "scrollEl" }] : /* istanbul ignore next */ []);
	rows = signal([], ...ngDevMode ? [{ debugName: "rows" }] : /* istanbul ignore next */ []);
	total = signal(0, ...ngDevMode ? [{ debugName: "total" }] : /* istanbul ignore next */ []);
	page = signal(1, ...ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []);
	currentPageSize = signal(20, ...ngDevMode ? [{ debugName: "currentPageSize" }] : /* istanbul ignore next */ []);
	sort = signal(null, ...ngDevMode ? [{ debugName: "sort" }] : /* istanbul ignore next */ []);
	filters = signal({}, ...ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []);
	rangeDrafts = signal({}, ...ngDevMode ? [{ debugName: "rangeDrafts" }] : /* istanbul ignore next */ []);
	loading = signal(false, ...ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []);
	error = signal(null, ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	colWidths = signal({}, ...ngDevMode ? [{ debugName: "colWidths" }] : /* istanbul ignore next */ []);
	visibleWidth = signal(null, ...ngDevMode ? [{ debugName: "visibleWidth" }] : /* istanbul ignore next */ []);
	clientMode = computed(() => this.fetchData() === void 0, ...ngDevMode ? [{ debugName: "clientMode" }] : /* istanbul ignore next */ []);
	renderedRows = computed(() => {
		const rows = this.clientMode() ? this.data() ?? [] : this.rows();
		const rowClass = this.rowClass();
		return rows.map((row) => ({
			row,
			classes: rowClass ? toClassList(rowClass(row)) : null
		}));
	}, ...ngDevMode ? [{ debugName: "renderedRows" }] : /* istanbul ignore next */ []);
	hasWrap = computed(() => this.columns().some((col) => col.wrap()), ...ngDevMode ? [{ debugName: "hasWrap" }] : /* istanbul ignore next */ []);
	showFilterRow = computed(() => !this.clientMode() && this.columns().some((col) => col.filterType() !== null), ...ngDevMode ? [{ debugName: "showFilterRow" }] : /* istanbul ignore next */ []);
	tableCols = computed(() => this.columns().map((col) => {
		const flex = col.flex();
		return flex !== null ? `minmax(${col.minWidth()}px, ${flex}fr)` : `${this.colWidths()[col.key()] ?? col.width()}px`;
	}).join(" "), ...ngDevMode ? [{ debugName: "tableCols" }] : /* istanbul ignore next */ []);
	tableMinWidth = computed(() => this.columns().reduce((sum, col) => {
		return sum + (col.flex() !== null ? col.minWidth() : this.colWidths()[col.key()] ?? col.width());
	}, 0), ...ngDevMode ? [{ debugName: "tableMinWidth" }] : /* istanbul ignore next */ []);
	totalPages = computed(() => Math.max(1, Math.ceil(this.total() / this.currentPageSize())), ...ngDevMode ? [{ debugName: "totalPages" }] : /* istanbul ignore next */ []);
	rangeStart = computed(() => this.total() === 0 ? 0 : (this.page() - 1) * this.currentPageSize() + 1, ...ngDevMode ? [{ debugName: "rangeStart" }] : /* istanbul ignore next */ []);
	rangeEnd = computed(() => Math.min(this.page() * this.currentPageSize(), this.total()), ...ngDevMode ? [{ debugName: "rangeEnd" }] : /* istanbul ignore next */ []);
	hasMore = computed(() => this.rows().length < this.total(), ...ngDevMode ? [{ debugName: "hasMore" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const cols = this.columns();
			this.colWidths.update((widths) => {
				let changed = false;
				const next = { ...widths };
				for (const col of cols) if (!(col.key() in next)) {
					next[col.key()] = col.width();
					changed = true;
				}
				return changed ? next : widths;
			});
		});
		const destroyRef = inject(DestroyRef);
		afterNextRender(() => {
			if (typeof ResizeObserver === "undefined") return;
			const observer = new ResizeObserver((entries) => this.visibleWidth.set(entries[0].contentRect.width));
			observer.observe(this.scrollEl().nativeElement);
			destroyRef.onDestroy(() => observer.disconnect());
		});
	}
	ngOnInit() {
		if (this.fetchData() === void 0 === (this.data() === void 0)) throw new Error("RsTable: Genau einer der Inputs \"fetchData\" oder \"data\" muss gesetzt sein.");
		if (this.clientMode()) return;
		this.currentPageSize.set(this.initialPageSize() ?? this.pageSizeOptions()[1] ?? this.pageSizeOptions()[0] ?? 20);
		this.load(false);
	}
	reload() {
		this.load(false);
	}
	isSortable(col) {
		return col.sortable() && !this.clientMode();
	}
	ariaSort(col) {
		if (!this.isSortable(col)) return null;
		const sort = this.sort();
		if (sort?.column !== col.key()) return "none";
		return sort.direction === "asc" ? "ascending" : "descending";
	}
	filterLabel(col) {
		return `Filter: ${col.header() || col.key()}`;
	}
	toggleSort(key) {
		const current = this.sort();
		if (!current || current.column !== key) this.sort.set({
			column: key,
			direction: "asc"
		});
		else if (current.direction === "asc") this.sort.set({
			column: key,
			direction: "desc"
		});
		else this.sort.set(null);
		this.page.set(1);
		this.load(false);
	}
	commitFilter(key, value) {
		this.filters.update((filters) => {
			const next = { ...filters };
			if (value === "" || value === null || value === void 0) delete next[key];
			else next[key] = value;
			return next;
		});
		this.page.set(1);
		this.load(false);
	}
	commitRangeFilter(key, part, value) {
		const draft = {
			...this.rangeDrafts()[key] ?? {
				from: null,
				to: null
			},
			[part]: value
		};
		this.rangeDrafts.update((drafts) => ({
			...drafts,
			[key]: draft
		}));
		this.commitFilter(key, draft.from || draft.to ? draft : null);
	}
	maxLines(col) {
		const maxLines = col.maxLines();
		return col.wrap() && maxLines !== null && maxLines > 0 ? maxLines : null;
	}
	cellValue(row, key) {
		const value = row[key];
		return value === null || value === void 0 ? "" : String(value);
	}
	makeCommitFn(key) {
		return (value) => this.commitFilter(key, value);
	}
	clearFilter(key, input) {
		if (input) input.value = "";
		this.rangeDrafts.update((drafts) => {
			const next = { ...drafts };
			delete next[key];
			return next;
		});
		this.commitFilter(key, null);
	}
	goToPage(delta) {
		const next = Math.min(this.totalPages(), Math.max(1, this.page() + delta));
		if (next !== this.page()) {
			this.page.set(next);
			this.load(false);
		}
	}
	changePageSize(size) {
		this.currentPageSize.set(size);
		this.page.set(1);
		this.load(false);
	}
	onBodyScroll(event) {
		if (this.clientMode() || this.mode() !== "infinite" || this.loading() || !this.hasMore()) return;
		const el = event.target;
		if (el.scrollTop + el.clientHeight >= el.scrollHeight - 40) {
			this.page.update((p) => p + 1);
			this.load(true);
		}
	}
	startResize(event, key) {
		event.preventDefault();
		const startX = event.clientX;
		const startWidth = this.colWidths()[key] ?? 160;
		const minWidth = this.columns().find((c) => c.key() === key)?.minWidth() ?? 60;
		const onMouseMove = (moveEvent) => {
			const next = Math.max(minWidth, startWidth + (moveEvent.clientX - startX));
			this.colWidths.update((widths) => ({
				...widths,
				[key]: next
			}));
		};
		const onMouseUp = () => {
			document.removeEventListener("mousemove", onMouseMove);
			document.removeEventListener("mouseup", onMouseUp);
		};
		document.addEventListener("mousemove", onMouseMove);
		document.addEventListener("mouseup", onMouseUp);
	}
	load(append) {
		const fetchData = this.fetchData();
		if (!fetchData) return;
		this.loading.set(true);
		this.error.set(null);
		fetchData({
			page: this.page(),
			pageSize: this.currentPageSize(),
			sort: this.sort(),
			filters: this.filters()
		}).then((result) => {
			this.loading.set(false);
			this.total.set(result.total);
			this.rows.set(append ? [...this.rows(), ...result.rows] : result.rows);
		}, (err) => {
			this.loading.set(false);
			this.error.set("Fehler beim Laden der Daten.");
			console.error(err);
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsTable,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsTable,
		isStandalone: true,
		selector: "rs-table",
		inputs: {
			fetchData: {
				classPropertyName: "fetchData",
				publicName: "fetchData",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			data: {
				classPropertyName: "data",
				publicName: "data",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pageSizeOptions: {
				classPropertyName: "pageSizeOptions",
				publicName: "pageSizeOptions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			initialPageSize: {
				classPropertyName: "initialPageSize",
				publicName: "pageSize",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rowClass: {
				classPropertyName: "rowClass",
				publicName: "rowClass",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		queries: [{
			propertyName: "columns",
			predicate: RsTableColumn,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "scrollEl",
			first: true,
			predicate: ["scroll"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "<div\n  class=\"rs-table\"\n  [class.rs-table--loading]=\"loading()\"\n  [class.rs-table--auto-height]=\"clientMode()\"\n  [class.rs-table--infinite]=\"mode() === 'infinite' && !clientMode()\"\n  [class.rs-table--wrap]=\"hasWrap()\"\n  [style.--rs-table-cols]=\"tableCols()\"\n  [style.--rs-table-min-width]=\"tableMinWidth() + 'px'\"\n  [style.--rs-table-page-size]=\"currentPageSize()\"\n  [style.--rs-table-visible-width]=\"visibleWidth() === null ? null : visibleWidth() + 'px'\"\n>\n  <div\n    #scroll\n    class=\"rs-table__scroll\"\n    role=\"table\"\n    [attr.aria-label]=\"label() || null\"\n    [attr.aria-busy]=\"loading() ? 'true' : null\"\n  >\n    <div class=\"rs-table__head\" role=\"rowgroup\">\n      <div class=\"rs-table__header\" role=\"row\">\n        @for (col of columns(); track col.key()) {\n          <div\n            class=\"rs-table__head-cell\"\n            role=\"columnheader\"\n            [attr.aria-sort]=\"ariaSort(col)\"\n            [class.rs-table__head-cell--sortable]=\"isSortable(col)\"\n            [class.rs-table__head-cell--end]=\"col.align() === 'end'\"\n            [class.rs-table__head-cell--sorted-asc]=\"\n              sort()?.column === col.key() && sort()?.direction === 'asc'\n            \"\n            [class.rs-table__head-cell--sorted-desc]=\"\n              sort()?.column === col.key() && sort()?.direction === 'desc'\n            \"\n          >\n            <button\n              type=\"button\"\n              class=\"rs-table__sort-btn\"\n              [disabled]=\"!isSortable(col)\"\n              (click)=\"isSortable(col) && toggleSort(col.key())\"\n            >\n              <span>{{ col.header() }}</span>\n              <span class=\"rs-table__sort-icon\"></span>\n            </button>\n            @if (col.resizable() && col.flex() === null) {\n              <div\n                class=\"rs-table__resize-handle\"\n                (mousedown)=\"startResize($event, col.key())\"\n              ></div>\n            }\n          </div>\n        }\n      </div>\n\n      @if (showFilterRow()) {\n        <div class=\"rs-table__filter-row\" role=\"row\">\n          @for (col of columns(); track col.key()) {\n            <div class=\"rs-table__filter-cell\" role=\"cell\">\n              @switch (col.filterType()) {\n                @case ('text') {\n                  <input\n                    class=\"rs-input\"\n                    type=\"text\"\n                    #filterInput\n                    [attr.aria-label]=\"filterLabel(col)\"\n                    (keydown.enter)=\"commitFilter(col.key(), filterInput.value)\"\n                    (blur)=\"commitFilter(col.key(), filterInput.value)\"\n                  />\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key(), filterInput)\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('number') {\n                  <input\n                    class=\"rs-input\"\n                    type=\"text\"\n                    inputmode=\"decimal\"\n                    #filterInput\n                    [attr.aria-label]=\"filterLabel(col)\"\n                    (keydown.enter)=\"commitFilter(col.key(), filterInput.value)\"\n                    (blur)=\"commitFilter(col.key(), filterInput.value)\"\n                  />\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key(), filterInput)\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('datetime') {\n                  <div\n                    class=\"rs-table__filter-group\"\n                    role=\"group\"\n                    [attr.aria-label]=\"filterLabel(col)\"\n                  >\n                    <rs-datepicker\n                      placeholder=\"Datum\"\n                      (dateChange)=\"commitFilter(col.key(), $event)\"\n                    />\n                  </div>\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key())\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('datetime-range') {\n                  <div\n                    class=\"rs-table__filter-group rs-table__filter-range\"\n                    role=\"group\"\n                    [attr.aria-label]=\"filterLabel(col)\"\n                  >\n                    <rs-datepicker\n                      placeholder=\"Von\"\n                      (dateChange)=\"commitRangeFilter(col.key(), 'from', $event)\"\n                    />\n                    <rs-datepicker\n                      placeholder=\"Bis\"\n                      (dateChange)=\"commitRangeFilter(col.key(), 'to', $event)\"\n                    />\n                  </div>\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key())\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('custom') {\n                  @if (col.filterDef(); as filterTemplate) {\n                    <div\n                      class=\"rs-table__filter-group\"\n                      role=\"group\"\n                      [attr.aria-label]=\"filterLabel(col)\"\n                    >\n                      <ng-container\n                        *ngTemplateOutlet=\"\n                          filterTemplate.templateRef;\n                          context: {\n                            $implicit: filters()[col.key()],\n                            commit: makeCommitFn(col.key()),\n                          }\n                        \"\n                      />\n                    </div>\n                  }\n                }\n              }\n            </div>\n          }\n        </div>\n      }\n    </div>\n\n    <div class=\"rs-table__body\" role=\"rowgroup\" (scroll)=\"onBodyScroll($event)\">\n      @if (loading() && renderedRows().length === 0) {\n        <div class=\"rs-table__loading-row\" role=\"row\">\n          <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n            <span class=\"rs-table__spinner\"></span><span>Lädt…</span>\n          </div>\n        </div>\n      } @else if (error()) {\n        <div class=\"rs-table__error\" role=\"row\">\n          <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n            {{ error() }}\n          </div>\n        </div>\n      } @else if (renderedRows().length === 0) {\n        <div class=\"rs-table__empty\" role=\"row\">\n          <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n            Keine Daten.\n          </div>\n        </div>\n      } @else {\n        @for (entry of renderedRows(); track $index) {\n          <div class=\"rs-table__row\" role=\"row\" [class]=\"entry.classes\">\n            @for (col of columns(); track col.key()) {\n              <div\n                class=\"rs-table__cell\"\n                role=\"cell\"\n                [class.rs-table__cell--end]=\"col.align() === 'end'\"\n                [class.rs-table__cell--wrap]=\"col.wrap()\"\n                [class.rs-table__cell--clamp]=\"maxLines(col) !== null\"\n                [style.--rs-table-max-lines]=\"maxLines(col)\"\n              >\n                @if (col.cellDef(); as cellTemplate) {\n                  <ng-container\n                    *ngTemplateOutlet=\"cellTemplate.templateRef; context: { $implicit: entry.row }\"\n                  />\n                } @else {\n                  <span rsTableText>{{ cellValue(entry.row, col.key()) }}</span>\n                }\n              </div>\n            }\n          </div>\n        }\n        @if (loading() && mode() === 'infinite') {\n          <div class=\"rs-table__loading-row\" role=\"row\">\n            <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n              <span class=\"rs-table__spinner\"></span><span>Lädt…</span>\n            </div>\n          </div>\n        }\n      }\n    </div>\n  </div>\n\n  @if (mode() === 'pager' && !clientMode()) {\n    <div class=\"rs-table__footer\">\n      <div class=\"rs-table__info\">{{ rangeStart() }}–{{ rangeEnd() }} von {{ total() }}</div>\n      <div class=\"rs-table__footer-right\">\n        <div class=\"rs-table__page-size\">\n          <span>Einträge/Seite</span>\n          <div class=\"rs-select-wrap\">\n            <select\n              class=\"rs-select\"\n              aria-label=\"Einträge pro Seite\"\n              (change)=\"changePageSize(+$any($event.target).value)\"\n            >\n              <!-- [selected] statt [value] am <select>: Dessen Wert würde gesetzt, bevor die\n                   Optionen aus dem @for existieren, und der Browser zeigte die erste Option. -->\n              @for (size of pageSizeOptions(); track size) {\n                <option [value]=\"size\" [selected]=\"size === currentPageSize()\">{{ size }}</option>\n              }\n            </select>\n          </div>\n        </div>\n        <div class=\"rs-table__pager\">\n          <button\n            type=\"button\"\n            class=\"rs-btn rs-btn--outline rs-btn--grey rs-btn--sm\"\n            [disabled]=\"page() <= 1\"\n            (click)=\"goToPage(-1)\"\n          >\n            Zurück\n          </button>\n          <span class=\"rs-table__page\">Seite {{ page() }} / {{ totalPages() }}</span>\n          <button\n            type=\"button\"\n            class=\"rs-btn rs-btn--outline rs-btn--grey rs-btn--sm\"\n            [disabled]=\"page() >= totalPages()\"\n            (click)=\"goToPage(1)\"\n          >\n            Weiter\n          </button>\n        </div>\n      </div>\n    </div>\n  }\n</div>\n",
		dependencies: [
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			},
			{
				kind: "component",
				type: RsDatepicker,
				selector: "rs-datepicker",
				inputs: [
					"withTime",
					"placeholder",
					"minDate",
					"maxDate",
					"disabled",
					"invalid",
					"date",
					"value",
					"time"
				],
				outputs: [
					"dateChange",
					"valueChange",
					"timeChange",
					"touch"
				]
			},
			{
				kind: "directive",
				type: RsTableText,
				selector: "[rsTableText]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsTable,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-table",
			imports: [
				NgTemplateOutlet,
				RsDatepicker,
				RsTableText
			],
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: "<div\n  class=\"rs-table\"\n  [class.rs-table--loading]=\"loading()\"\n  [class.rs-table--auto-height]=\"clientMode()\"\n  [class.rs-table--infinite]=\"mode() === 'infinite' && !clientMode()\"\n  [class.rs-table--wrap]=\"hasWrap()\"\n  [style.--rs-table-cols]=\"tableCols()\"\n  [style.--rs-table-min-width]=\"tableMinWidth() + 'px'\"\n  [style.--rs-table-page-size]=\"currentPageSize()\"\n  [style.--rs-table-visible-width]=\"visibleWidth() === null ? null : visibleWidth() + 'px'\"\n>\n  <div\n    #scroll\n    class=\"rs-table__scroll\"\n    role=\"table\"\n    [attr.aria-label]=\"label() || null\"\n    [attr.aria-busy]=\"loading() ? 'true' : null\"\n  >\n    <div class=\"rs-table__head\" role=\"rowgroup\">\n      <div class=\"rs-table__header\" role=\"row\">\n        @for (col of columns(); track col.key()) {\n          <div\n            class=\"rs-table__head-cell\"\n            role=\"columnheader\"\n            [attr.aria-sort]=\"ariaSort(col)\"\n            [class.rs-table__head-cell--sortable]=\"isSortable(col)\"\n            [class.rs-table__head-cell--end]=\"col.align() === 'end'\"\n            [class.rs-table__head-cell--sorted-asc]=\"\n              sort()?.column === col.key() && sort()?.direction === 'asc'\n            \"\n            [class.rs-table__head-cell--sorted-desc]=\"\n              sort()?.column === col.key() && sort()?.direction === 'desc'\n            \"\n          >\n            <button\n              type=\"button\"\n              class=\"rs-table__sort-btn\"\n              [disabled]=\"!isSortable(col)\"\n              (click)=\"isSortable(col) && toggleSort(col.key())\"\n            >\n              <span>{{ col.header() }}</span>\n              <span class=\"rs-table__sort-icon\"></span>\n            </button>\n            @if (col.resizable() && col.flex() === null) {\n              <div\n                class=\"rs-table__resize-handle\"\n                (mousedown)=\"startResize($event, col.key())\"\n              ></div>\n            }\n          </div>\n        }\n      </div>\n\n      @if (showFilterRow()) {\n        <div class=\"rs-table__filter-row\" role=\"row\">\n          @for (col of columns(); track col.key()) {\n            <div class=\"rs-table__filter-cell\" role=\"cell\">\n              @switch (col.filterType()) {\n                @case ('text') {\n                  <input\n                    class=\"rs-input\"\n                    type=\"text\"\n                    #filterInput\n                    [attr.aria-label]=\"filterLabel(col)\"\n                    (keydown.enter)=\"commitFilter(col.key(), filterInput.value)\"\n                    (blur)=\"commitFilter(col.key(), filterInput.value)\"\n                  />\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key(), filterInput)\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('number') {\n                  <input\n                    class=\"rs-input\"\n                    type=\"text\"\n                    inputmode=\"decimal\"\n                    #filterInput\n                    [attr.aria-label]=\"filterLabel(col)\"\n                    (keydown.enter)=\"commitFilter(col.key(), filterInput.value)\"\n                    (blur)=\"commitFilter(col.key(), filterInput.value)\"\n                  />\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key(), filterInput)\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('datetime') {\n                  <div\n                    class=\"rs-table__filter-group\"\n                    role=\"group\"\n                    [attr.aria-label]=\"filterLabel(col)\"\n                  >\n                    <rs-datepicker\n                      placeholder=\"Datum\"\n                      (dateChange)=\"commitFilter(col.key(), $event)\"\n                    />\n                  </div>\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key())\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('datetime-range') {\n                  <div\n                    class=\"rs-table__filter-group rs-table__filter-range\"\n                    role=\"group\"\n                    [attr.aria-label]=\"filterLabel(col)\"\n                  >\n                    <rs-datepicker\n                      placeholder=\"Von\"\n                      (dateChange)=\"commitRangeFilter(col.key(), 'from', $event)\"\n                    />\n                    <rs-datepicker\n                      placeholder=\"Bis\"\n                      (dateChange)=\"commitRangeFilter(col.key(), 'to', $event)\"\n                    />\n                  </div>\n                  @if (filters()[col.key()] !== undefined) {\n                    <button\n                      type=\"button\"\n                      class=\"rs-table__filter-clear\"\n                      aria-label=\"Filter zurücksetzen\"\n                      (click)=\"clearFilter(col.key())\"\n                    >\n                      ×\n                    </button>\n                  }\n                }\n                @case ('custom') {\n                  @if (col.filterDef(); as filterTemplate) {\n                    <div\n                      class=\"rs-table__filter-group\"\n                      role=\"group\"\n                      [attr.aria-label]=\"filterLabel(col)\"\n                    >\n                      <ng-container\n                        *ngTemplateOutlet=\"\n                          filterTemplate.templateRef;\n                          context: {\n                            $implicit: filters()[col.key()],\n                            commit: makeCommitFn(col.key()),\n                          }\n                        \"\n                      />\n                    </div>\n                  }\n                }\n              }\n            </div>\n          }\n        </div>\n      }\n    </div>\n\n    <div class=\"rs-table__body\" role=\"rowgroup\" (scroll)=\"onBodyScroll($event)\">\n      @if (loading() && renderedRows().length === 0) {\n        <div class=\"rs-table__loading-row\" role=\"row\">\n          <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n            <span class=\"rs-table__spinner\"></span><span>Lädt…</span>\n          </div>\n        </div>\n      } @else if (error()) {\n        <div class=\"rs-table__error\" role=\"row\">\n          <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n            {{ error() }}\n          </div>\n        </div>\n      } @else if (renderedRows().length === 0) {\n        <div class=\"rs-table__empty\" role=\"row\">\n          <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n            Keine Daten.\n          </div>\n        </div>\n      } @else {\n        @for (entry of renderedRows(); track $index) {\n          <div class=\"rs-table__row\" role=\"row\" [class]=\"entry.classes\">\n            @for (col of columns(); track col.key()) {\n              <div\n                class=\"rs-table__cell\"\n                role=\"cell\"\n                [class.rs-table__cell--end]=\"col.align() === 'end'\"\n                [class.rs-table__cell--wrap]=\"col.wrap()\"\n                [class.rs-table__cell--clamp]=\"maxLines(col) !== null\"\n                [style.--rs-table-max-lines]=\"maxLines(col)\"\n              >\n                @if (col.cellDef(); as cellTemplate) {\n                  <ng-container\n                    *ngTemplateOutlet=\"cellTemplate.templateRef; context: { $implicit: entry.row }\"\n                  />\n                } @else {\n                  <span rsTableText>{{ cellValue(entry.row, col.key()) }}</span>\n                }\n              </div>\n            }\n          </div>\n        }\n        @if (loading() && mode() === 'infinite') {\n          <div class=\"rs-table__loading-row\" role=\"row\">\n            <div class=\"rs-table__state-cell\" role=\"cell\" [attr.aria-colspan]=\"columns().length\">\n              <span class=\"rs-table__spinner\"></span><span>Lädt…</span>\n            </div>\n          </div>\n        }\n      }\n    </div>\n  </div>\n\n  @if (mode() === 'pager' && !clientMode()) {\n    <div class=\"rs-table__footer\">\n      <div class=\"rs-table__info\">{{ rangeStart() }}–{{ rangeEnd() }} von {{ total() }}</div>\n      <div class=\"rs-table__footer-right\">\n        <div class=\"rs-table__page-size\">\n          <span>Einträge/Seite</span>\n          <div class=\"rs-select-wrap\">\n            <select\n              class=\"rs-select\"\n              aria-label=\"Einträge pro Seite\"\n              (change)=\"changePageSize(+$any($event.target).value)\"\n            >\n              <!-- [selected] statt [value] am <select>: Dessen Wert würde gesetzt, bevor die\n                   Optionen aus dem @for existieren, und der Browser zeigte die erste Option. -->\n              @for (size of pageSizeOptions(); track size) {\n                <option [value]=\"size\" [selected]=\"size === currentPageSize()\">{{ size }}</option>\n              }\n            </select>\n          </div>\n        </div>\n        <div class=\"rs-table__pager\">\n          <button\n            type=\"button\"\n            class=\"rs-btn rs-btn--outline rs-btn--grey rs-btn--sm\"\n            [disabled]=\"page() <= 1\"\n            (click)=\"goToPage(-1)\"\n          >\n            Zurück\n          </button>\n          <span class=\"rs-table__page\">Seite {{ page() }} / {{ totalPages() }}</span>\n          <button\n            type=\"button\"\n            class=\"rs-btn rs-btn--outline rs-btn--grey rs-btn--sm\"\n            [disabled]=\"page() >= totalPages()\"\n            (click)=\"goToPage(1)\"\n          >\n            Weiter\n          </button>\n        </div>\n      </div>\n    </div>\n  }\n</div>\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		fetchData: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fetchData",
				required: false
			}]
		}],
		data: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "data",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		pageSizeOptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageSizeOptions",
				required: false
			}]
		}],
		initialPageSize: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pageSize",
				required: false
			}]
		}],
		rowClass: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rowClass",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		columns: [{
			type: i0.ContentChildren,
			args: [i0.forwardRef(() => RsTableColumn), { isSignal: true }]
		}],
		scrollEl: [{
			type: i0.ViewChild,
			args: ["scroll", { isSignal: true }]
		}]
	}
});
function toClassList(value) {
	if (!value) return null;
	return typeof value === "string" ? value : [...value];
}
const DEFAULT_DURATION = 6e3;
var RsToastService = class RsToastService {
	_toasts = signal([], ...ngDevMode ? [{ debugName: "_toasts" }] : /* istanbul ignore next */ []);
	toasts = this._toasts.asReadonly();
	nextId = 1;
	show(options) {
		const toast = {
			id: this.nextId++,
			message: options.message,
			title: options.title,
			variant: options.variant ?? "neutral",
			action: options.action,
			duration: Math.max(0, options.duration ?? DEFAULT_DURATION),
			dismissible: options.dismissible ?? true
		};
		this._toasts.update((toasts) => [...toasts, toast].slice(-3));
		return {
			id: toast.id,
			dismiss: () => this.dismiss(toast.id)
		};
	}
	dismiss(id) {
		if (this._toasts().some((toast) => toast.id === id)) this._toasts.update((toasts) => toasts.filter((toast) => toast.id !== id));
	}
	clear() {
		this._toasts.set([]);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsToastService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsToastService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsToastService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const ACTION_COLOR = {
	neutral: "rs-btn--grey",
	ok: "rs-btn--green",
	warn: "rs-btn--yellow",
	crit: "rs-btn--red"
};
var RsToastItem = class RsToastItem {
	toast = input.required(...ngDevMode ? [{ debugName: "toast" }] : /* istanbul ignore next */ []);
	service = inject(RsToastService);
	document = inject(DOCUMENT);
	element = inject(ElementRef).nativeElement;
	actionColor = computed(() => ACTION_COLOR[this.toast().variant], ...ngDevMode ? [{ debugName: "actionColor" }] : /* istanbul ignore next */ []);
	timer;
	remaining = 0;
	startedAt = 0;
	hovered = false;
	focused = false;
	returnFocusTo = null;
	constructor() {
		inject(DestroyRef).onDestroy(() => clearTimeout(this.timer));
	}
	ngOnInit() {
		this.remaining = this.toast().duration;
		this.resume();
	}
	setHovered(hovered) {
		this.hovered = hovered;
		this.updateTimer();
	}
	onFocusIn(event) {
		const from = event.relatedTarget;
		if (!this.focused && from instanceof HTMLElement && !this.element.contains(from)) this.returnFocusTo = from;
		this.focused = true;
		this.updateTimer();
	}
	onFocusOut(event) {
		const to = event.relatedTarget;
		if (to instanceof Node && this.element.contains(to)) return;
		this.focused = false;
		this.updateTimer();
	}
	onEscape() {
		if (this.toast().dismissible) this.close();
	}
	runAction() {
		try {
			this.toast().action?.handler();
		} finally {
			this.close();
		}
	}
	close() {
		if (this.element.contains(this.document.activeElement) && this.returnFocusTo?.isConnected) this.returnFocusTo.focus();
		this.service.dismiss(this.toast().id);
	}
	updateTimer() {
		if (this.hovered || this.focused) this.pause();
		else this.resume();
	}
	pause() {
		if (this.timer === void 0) return;
		clearTimeout(this.timer);
		this.timer = void 0;
		this.remaining -= Date.now() - this.startedAt;
	}
	resume() {
		if (this.timer !== void 0 || this.toast().duration === 0) return;
		this.startedAt = Date.now();
		this.timer = setTimeout(() => {
			this.timer = void 0;
			this.service.dismiss(this.toast().id);
		}, Math.max(0, this.remaining));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsToastItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsToastItem,
		isStandalone: true,
		selector: "rs-toast-item",
		inputs: { toast: {
			classPropertyName: "toast",
			publicName: "toast",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: {
			listeners: {
				"mouseenter": "setHovered(true)",
				"mouseleave": "setHovered(false)",
				"focusin": "onFocusIn($event)",
				"focusout": "onFocusOut($event)",
				"keydown.escape": "onEscape()"
			},
			properties: {
				"class.rs-toast--neutral": "toast().variant === 'neutral'",
				"class.rs-toast--ok": "toast().variant === 'ok'",
				"class.rs-toast--warn": "toast().variant === 'warn'",
				"class.rs-toast--crit": "toast().variant === 'crit'"
			},
			classAttribute: "rs-toast"
		},
		ngImport: i0,
		template: "<div class=\"rs-toast__content\">\n  @if (toast().title) {\n    <p class=\"rs-toast__title\">{{ toast().title }}</p>\n  }\n  <p class=\"rs-toast__message\">{{ toast().message }}</p>\n</div>\n@if (toast().action; as action) {\n  <button\n    type=\"button\"\n    class=\"rs-btn rs-btn--outline rs-btn--sm rs-toast__action\"\n    [class]=\"actionColor()\"\n    (click)=\"runAction()\"\n  >\n    {{ action.label }}\n  </button>\n}\n@if (toast().dismissible) {\n  <button type=\"button\" class=\"rs-toast__close\" aria-label=\"Meldung schließen\" (click)=\"close()\">\n    <span aria-hidden=\"true\">×</span>\n  </button>\n}\n",
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsToastItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-toast-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "rs-toast",
				"[class.rs-toast--neutral]": "toast().variant === 'neutral'",
				"[class.rs-toast--ok]": "toast().variant === 'ok'",
				"[class.rs-toast--warn]": "toast().variant === 'warn'",
				"[class.rs-toast--crit]": "toast().variant === 'crit'",
				"(mouseenter)": "setHovered(true)",
				"(mouseleave)": "setHovered(false)",
				"(focusin)": "onFocusIn($event)",
				"(focusout)": "onFocusOut($event)",
				"(keydown.escape)": "onEscape()"
			},
			template: "<div class=\"rs-toast__content\">\n  @if (toast().title) {\n    <p class=\"rs-toast__title\">{{ toast().title }}</p>\n  }\n  <p class=\"rs-toast__message\">{{ toast().message }}</p>\n</div>\n@if (toast().action; as action) {\n  <button\n    type=\"button\"\n    class=\"rs-btn rs-btn--outline rs-btn--sm rs-toast__action\"\n    [class]=\"actionColor()\"\n    (click)=\"runAction()\"\n  >\n    {{ action.label }}\n  </button>\n}\n@if (toast().dismissible) {\n  <button type=\"button\" class=\"rs-toast__close\" aria-label=\"Meldung schließen\" (click)=\"close()\">\n    <span aria-hidden=\"true\">×</span>\n  </button>\n}\n"
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { toast: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "toast",
			required: true
		}]
	}] }
});
var RsToastHost = class RsToastHost {
	service = inject(RsToastService);
	announced = linkedSignal({
		...ngDevMode ? { debugName: "announced" } : /* istanbul ignore next */ {},
		source: this.service.toasts,
		computation: (toasts, previous) => {
			const newest = toasts.at(-1) ?? null;
			const last = previous?.value ?? null;
			if (newest && (!last || newest.id > last.id)) return newest;
			return last && toasts.some((toast) => toast.id === last.id) ? last : null;
		}
	});
	politeAnnouncement = computed(() => {
		const toast = this.announced();
		return toast && toast.variant !== "crit" ? [toast] : [];
	}, ...ngDevMode ? [{ debugName: "politeAnnouncement" }] : /* istanbul ignore next */ []);
	alertAnnouncement = computed(() => {
		const toast = this.announced();
		return toast?.variant === "crit" ? [toast] : [];
	}, ...ngDevMode ? [{ debugName: "alertAnnouncement" }] : /* istanbul ignore next */ []);
	announcementText(toast) {
		return toast.title ? `${toast.title}: ${toast.message}` : toast.message;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.0",
		ngImport: i0,
		type: RsToastHost,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.0",
		type: RsToastHost,
		isStandalone: true,
		selector: "rs-toast-host",
		host: { classAttribute: "rs-toast-host" },
		ngImport: i0,
		template: "@for (toast of service.toasts(); track toast.id) {\n  <rs-toast-item [toast]=\"toast\" />\n}\n<!-- Neue Elemente (track per id) lösen die Ansage aus, auch bei gleichem Text. -->\n<div class=\"rs-toast-host__announcer\" aria-live=\"polite\">\n  @for (toast of politeAnnouncement(); track toast.id) {\n    <span>{{ announcementText(toast) }}</span>\n  }\n</div>\n<div class=\"rs-toast-host__announcer\" role=\"alert\">\n  @for (toast of alertAnnouncement(); track toast.id) {\n    <span>{{ announcementText(toast) }}</span>\n  }\n</div>\n",
		dependencies: [{
			kind: "component",
			type: RsToastItem,
			selector: "rs-toast-item",
			inputs: ["toast"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.0",
	ngImport: i0,
	type: RsToastHost,
	decorators: [{
		type: Component,
		args: [{
			selector: "rs-toast-host",
			imports: [RsToastItem],
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "rs-toast-host" },
			template: "@for (toast of service.toasts(); track toast.id) {\n  <rs-toast-item [toast]=\"toast\" />\n}\n<!-- Neue Elemente (track per id) lösen die Ansage aus, auch bei gleichem Text. -->\n<div class=\"rs-toast-host__announcer\" aria-live=\"polite\">\n  @for (toast of politeAnnouncement(); track toast.id) {\n    <span>{{ announcementText(toast) }}</span>\n  }\n</div>\n<div class=\"rs-toast-host__announcer\" role=\"alert\">\n  @for (toast of alertAnnouncement(); track toast.id) {\n    <span>{{ announcementText(toast) }}</span>\n  }\n</div>\n"
		}]
	}]
});
export { RS_GAUGE_ROUND_CIRCUMFERENCE, RsAccordion, RsAccordionItem, RsAutocomplete, RsCellDef, RsDatepicker, RsDropdown, RsFilterDef, RsGauge, RsList, RsLogPanel, RsModal, RsPasswordField, RsPopover, RsPopoverTrigger, RsSidenav, RsTable, RsTableColumn, RsTableText, RsTabs, RsToastHost, RsToastService, RsToggle, RsTooltip, RsWizard, RsWizardPage, flipIfNeeded, registerAnchoredPopup, registerDismissibleOverlay };

//# sourceMappingURL=custom-components.mjs.map