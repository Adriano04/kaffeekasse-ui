# custom-components

Angular-Portierung der Raumschiff-Interface-Widget-Bibliothek aus
`widgets-spaceship/` (siehe dort `README.md`/`specification.md` für die
vollständige, framework-unabhängige Spezifikation). CSS-Vertrag
(Klassennamen, BEM-Modifier, Status-Konvention grün/gelb/rot) ist 1:1
übernommen; interaktive Widgets sind echte Angular-Components mit
korrektem `DestroyRef`-basiertem Cleanup.

Pro-Widget-Doku mit Code-Beispielen: [`../../documentation/`](../../documentation/README.md).

## Einbindung in ein anderes Projekt (z. B. `beverage-management-ui`)

Diese Library wird **nicht** über eine Registry (npm oder privat) verteilt,
sondern als lokale `file:`-Dependency auf ein per `npm pack` erzeugtes,
versioniertes Tarball installiert — verhält sich für das Zielprojekt
trotzdem wie eine ganz normale, gepinnte npm-Dependency (Version +
Integritäts-Hash landen in dessen `package-lock.json`).

1. **Library bauen und packen** (vom Repo-Root `quarkus-getraenkeverwaltung/`
   aus):

   ```bash
   npm run pack:custom-components
   ```

   Baut die Library und erzeugt
   `custom-components/dist/custom-components-<version>.tgz`.

2. **Als Dependency eintragen**, im `package.json` des Zielprojekts (Pfad
   relativ zum Zielprojekt-Ordner, also z. B. aus Sicht von
   `beverage-management-ui/`):

   ```json
   "dependencies": {
     "custom-components": "file:../custom-components/dist/custom-components-<version>.tgz"
   }
   ```

   Danach im Zielprojekt `npm install` ausführen.

3. **Styles global einbinden** — pro Theme (siehe [Themes](#themes) unten)
   liegen nach der Installation drei CSS-Dateien unter
   `node_modules/custom-components/styles/<theme>/`: `tokens.css`,
   `widgets.css`, optional `tokens-light.css`. Ladereihenfolge beachten:
   `tokens.css` **vor** `widgets.css` (definiert die CSS-Variablen, auf die
   `widgets.css` sich bezieht); `tokens-light.css` (falls genutzt) danach.
   In `angular.json` des Zielprojekts, hier Beispiel für das
   Standard-Theme `space-ship`:

   ```json
   "styles": [
     "node_modules/custom-components/styles/space-ship/tokens.css",
     "node_modules/custom-components/styles/space-ship/widgets.css",
     "node_modules/custom-components/styles/space-ship/tokens-light.css",
     "src/styles.css"
   ]
   ```

4. **Root-Element** (i. d. R. `<body>` in `src/index.html`) braucht die
   Klasse `rs-root` für Hintergrundfarbe und Basistypografie:

   ```html
   <body class="rs-root">
   ```

5. **Components/Utilities importieren** wie jede andere npm-Library:

   ```ts
   import { RsToggle } from 'custom-components';
   ```

### Version hochzählen

Die maßgebliche Versionsnummer steht in **`projects/custom-components/package.json`**
(nicht im Workspace-Root-`package.json` — dessen Version ist nur für das
Tooling des Workspaces selbst und für die Library irrelevant). Aus dieser
Datei übernimmt ng-packagr die Version ins gebaute `dist/custom-components/package.json`,
und `npm pack` benennt den Tarball danach (`custom-components-<version>.tgz`).

Zwei Wege, die Version zu bumpen:

- **Manuell**: `"version"` in `projects/custom-components/package.json`
  direkt editieren, z. B. `"0.0.1"` → `"0.0.2"`.
- **Über npm CLI** (übernimmt Semver-Logik automatisch):

  ```bash
  cd projects/custom-components
  npm version patch --no-git-tag-version   # 0.0.1 → 0.0.2
  # oder: minor (neue Components/Features) / major (Breaking Changes)
  ```

  `--no-git-tag-version` ist Pflicht — ohne das versucht npm, einen
  Git-Commit + Tag zu erzeugen; das Verzeichnis ist aber kein eigenes
  Git-Repo (Teil des Monorepos), das würde ungewollt Repo-weite Änderungen
  committen.

Danach greift der normale Publish-Zyklus: Schritt 1 (`npm run pack:custom-components`)
erzeugt den neuen, versionierten Tarball.

### Eine neue Version im Zielprojekt übernehmen

- **Version unverändert, nur Inhalt geändert** (z. B. während der
  Entwicklung): Schritt 1 erneut ausführen, dann im Zielprojekt
  `npm update custom-components` ausführen. Ein reines `npm install`
  reicht hier **nicht** — npm erkennt bei unverändertem Tarball-Dateinamen
  keinen neuen Inhalt (empirisch verifiziert).
- **Version geändert**: den Dateinamen in der Dependency-Angabe im
  Zielprojekt auf `custom-components-<neue-version>.tgz` anpassen, dann
  `npm install`.

Hintergrund und Details: `../../CLAUDE.md`, Abschnitt "Consumption from
beverage-management-ui".

## Themes

`src/styles/` enthält mehrere **vollständig eigenständige** Themes,
jeweils in einem eigenen Unterordner mit demselben Datei-Trio
(`tokens.css`, `widgets.css`, `tokens-light.css`):

| Ordner | Beschreibung |
|---|---|
| `space-ship/` | Standard. HUD-Look der Raumschiff-Interface-Bibliothek (grün/gelb/rot auf near-black), 1:1 aus `widgets-spaceship/` übernommen. |
| `relaxed-coffee/` | Warme Kaffee-Palette (Espresso-Braun/Creme, Statusfarben in gedecktem Moosgrün/Karamell/Terrakotta statt Neon), runde Nunito-Schrift, größere Radien, weiche Schatten statt Glow und ruhigere Animationen, Labels in normaler Schreibweise statt Versalien. |

Jeder Theme-Ordner ist unabhängig nutzbar — Schritt 3 oben zeigt das
Einbinden von `space-ship/`; für `relaxed-coffee/` einfach `space-ship`
durch `relaxed-coffee` im Pfad ersetzen. **Nur eines der beiden `tokens.css`
gleichzeitig laden** — beide definieren dieselben Custom Properties auf
`:root`, bei gleichzeitigem Laden gewinnt schlicht das zuletzt eingebundene
(keine automatische Koexistenz wie bei Dark/Light, siehe unten).

`widgets.css` ist zwischen den Theme-Ordnern **bewusst byte-identisch
dupliziert** (referenziert ausschließlich `var(--rs-*)`, enthält selbst
keine Farben) — jeder Ordner soll für sich genommen vollständig und
kopierbar sein. Bei strukturellen Änderungen an `widgets.css` (neue
Widgets, neue Selektoren) müssen **beide** Kopien synchron gehalten werden.

Ein neues Theme hinzufügen: neuen Ordner unter `src/styles/<name>/`
anlegen, `widgets.css` 1:1 aus einem bestehenden Theme kopieren,
`tokens.css`/`tokens-light.css` mit neuer Farbpalette erstellen (gleiche
Variablennamen, nur Farbwerte ändern — Typografie/Radius/Abstand/
Transition-Tokens sind themeunabhängig und müssen nicht dupliziert
werden). Das ng-packagr-Asset-Glob (`**/*.css` in `ng-package.json`) nimmt
neue Theme-Ordner automatisch mit auf.

### Dark/Light (pro Theme)

Innerhalb **jedes** Themes ist Dark Mode der Standard (`tokens.css`). Light
Mode ist ein optionales Overlay (`tokens-light.css`), das ausschließlich
farbbezogene Custom Properties überschreibt (Flächen, Status grün/gelb/rot,
Text, Glow-/Hover-Tints) — Typografie, Radius, Abstand und Transition-Dauer
sind themeunabhängig.

Aktivierung über eine BEM-Modifier-Klasse auf dem Root-Element, zusätzlich
zu `rs-root` (gleiche Konvention wie bei allen anderen Widget-Modifiern,
z. B. `.rs-tile--crit`):

```html
<body class="rs-root rs-root--light">
```

Setup: `tokens-light.css` des jeweiligen Theme-Ordners zusätzlich **nach**
dessen `tokens.css`/`widgets.css` laden (siehe Schritt 3 oben) — es ist
rein additiv (scoped unter `.rs-root--light`) und beeinflusst nichts,
solange die Modifier-Klasse nicht gesetzt ist. Laufzeit-Umschalten (z. B.
per Theme-Toggle-Button) funktioniert durch einfaches Zu-/Abschalten der
Klasse auf dem Root-Element — die Showcase-App demonstriert das (`app.ts`,
`toggleTheme()`) für `space-ship`.

`--rs-overlay-scrim` (Modal-/Wizard-Backdrop) bleibt in Dark und Light
bewusst gleich dunkel — ein heller Overlay-Scrim wäre gegen einen ebenfalls
hellen Modal-Hintergrund kaum sichtbar.

## CSS-only Widgets (keine Angular-Component nötig)

Folgende Widgets bestehen ausschließlich aus CSS-Klassen — einfach auf
normales HTML anwenden, kein Import aus dieser Library nötig. Live-Beispiele
in der Showcase-App (`ng serve showcase`, Sektion „CSS-only Widgets"):

| Widget | Klassen | Spec |
|---|---|---|
| Buttons | `.rs-btn` + Varianten-/Status-/Größen-Modifier | §2 |
| Statuskachel (Card) | `.rs-tile` + `--ok`/`--warn`/`--crit`/`--off` | §4 |
| Gauges (statisch, ohne Ladeanimation) | `.rs-gauge-round` / `.rs-gauge-bar` | §5 |
| Badge / Badge-Count | `.rs-badge` / `.rs-badge-count` | §10 |
| Breadcrumb | `.rs-breadcrumb` | §12 |
| Tooltip | `[data-tooltip]` (+ `data-tooltip-pos="bottom"`); in Angular mit Direktive `RsTooltip` in der Top-Layer (siehe [Erweiterungen](#erweiterungen-gegenüber-der-spezifikation)) | §13 |
| Timeline | `.rs-timeline` (+ `--vertical`) | §17 |
| Typografie | `.rs-prose` | §22 |
| Natives Select | `.rs-select` / `.rs-select-wrap` (+ `--block` für volle Breite; in `.rs-field` so hoch wie `.rs-input`) | §21.6 |
| App-Bar | `.rs-app-bar` (+ `--sticky`/`--lift`/`--center`/`--large`) | — (noch kein Abschnitt, siehe [app-bar.md](../../documentation/css-only%20widgets/app-bar.md)) |
| Toolbar | `.rs-toolbar` (+ `--vertical`, `__group--joined`) | — (noch kein Abschnitt, siehe [toolbar.md](../../documentation/css-only%20widgets/toolbar.md)) |
| Card | `.rs-card` (+ `--interactive`, `--compact`) | — (noch kein Abschnitt, siehe [card.md](../../documentation/css-only%20widgets/card.md)) |
| Callout | `.rs-callout` (+ `--neutral`/`--ok`/`--warn`/`--crit`) | — (noch kein Abschnitt, siehe [callout.md](../../documentation/css-only%20widgets/callout.md)) |
| Kennzahl | `.rs-stat` (+ `--ok`/`--warn`/`--crit`/`--neutral`, `--lg`, `--inline`) | — (noch kein Abschnitt, siehe [stat.md](../../documentation/css-only%20widgets/stat.md)) |
| Eintragsliste | `.rs-item-list` (+ `--divided`/`--cards`, `__item--muted`, `__item--interactive`) | — (noch kein Abschnitt, siehe [item-list.md](../../documentation/css-only%20widgets/item-list.md)) |

Animierte Gauges (initialer Ladeeffekt beim runden Gauge) benötigen die
`RsGauge`-Component, siehe unten.

## Components

Jede Component setzt exakt den "JS-Vertrag" der jeweiligen Spec-Sektion um
(nicht den `demo.js`-Referenzcode). Live-Beispiele und manuelle
Verifikation in der Showcase-App (`ng serve showcase`, jeweils eigene
Sektion pro Widget).

| Component | Spec | Kurzbeschreibung |
|---|---|---|
| `RsToggle` | §3 | Slide-Toggle, Zustand als `model()` (`[(checked)]`) |
| `RsAccordion` / `RsAccordionItem` | §11 | Nur ein Panel gleichzeitig offen |
| `RsTabs` | §8 | Horizontale Tab-Leiste, reine Navigation (Panels selbst rendert der Consumer) |
| `RsSidenav` | §8 | Vertikale Sidebar-Navigation, gleiches Verhalten wie `RsTabs` |
| `RsGauge` | §5 | `variant="round"` (einmaliger Ladeeffekt via `afterNextRender`) / `"bar"` |
| `RsLogPanel` | §6 | Autoscroll bei neuem Eintrag (`afterRenderEffect`) |
| `RsPasswordField` | §9 | Sichtbarkeits-Toggle inkl. Icon/aria-label; reine Text-/Error-/Warn-Felder bleiben CSS-only |
| `RsModal` | §7 | Escape/Außenklick schließt; Markup wird per `@if` komplett auf-/abgebaut. Höchstens `90dvh` hoch, darüber scrollt der Inhalt |
| `RsPopover` + `RsPopoverTrigger` | §14 | Trigger ist eine Direktive auf dem eigenen `<button>` des Consumers (kein verschachteltes `<button>`). Panel als Popover in der Top-Layer (siehe [Erweiterungen](#erweiterungen-gegenüber-der-spezifikation)) |
| `RsTooltip` | §13 | Direktive auf `[data-tooltip]`: gleiches Markup wie der CSS-Tooltip, Text als Popover in der Top-Layer statt `::after`, Beschreibung per `aria-describedby` |
| `RsDropdown` | §15 | Single- und Multiselect (`multi`-Input), Suche, `flipIfNeeded`. Menü als Popover in der Top-Layer (siehe [Erweiterungen](#erweiterungen-gegenüber-der-spezifikation)) |
| `RsDatepicker` | §16 | Kalender, dt. Monatsnamen/Montag-Start; `withTime` für Datetime; `date`/`time` als `model()` statt `onChange`-Callback. Erweitert um `minDate`/`maxDate`, Tastatursteuerung und Signal Forms (siehe [Erweiterungen](#erweiterungen-gegenüber-der-spezifikation)) |
| `RsList` | §20 | `add()`-Methode + `values`-`model()`; von `RsAutocomplete` per `(commit)`-Event konsumierbar |
| `RsAutocomplete` | §19 | Freitext bleibt immer gültig; Hervorhebung über Angular-Interpolation (kein `innerHTML`, XSS-sicher per Konstruktion). Vorschlagsliste als Popover in der Top-Layer (siehe [Erweiterungen](#erweiterungen-gegenüber-der-spezifikation)) |
| `RsWizard` + `RsWizardPage` | §18 | `canProceed`-Input (präventives Sperren) und `validate`-Input (Fehler nach Klick zeigen) als generische Übersetzung der beiden Referenz-Validierungsmuster; Backdrop-Klick schließt bewusst nicht |
| `RsTable` + `RsTableColumn` | §21 | `<ng-template rsCellDef>` / `<ng-template rsFilterDef>` ersetzen die Vanilla-Render-Funktionen (Angular-CDK-artiges Column-Def-Muster); Pager- und Infinite-Scroll-Modus, Resize, Sortierung, alle Filtertypen. Erweitert um lokale Daten (`data`), flexible Spalten, Ausrichtung, Zeilen-Klassen, ARIA-Rollen, wirksame Ellipse mit `title` (`RsTableText`) und umbrechende Spalten (`wrap`, `maxLines`) (siehe [Erweiterungen](#erweiterungen-gegenüber-der-spezifikation)) |
| `RsToastService` + `RsToastHost` | — (noch kein Abschnitt, siehe [toast.md](../../documentation/angular%20component%20widgets/toast.md)) | Nicht-blockierende Kurzmeldung mit optionaler Aktion; höchstens 3 sichtbar, Zeitablauf pausiert bei Hover/Fokus, Live-Regionen für Screenreader, liegt über Modals |

### Geteilte Utilities

- `flipIfNeeded()` — Öffnungsrichtung (oben/unten) aus §14 („Geteilte
  Primitives“). Bleibt exportiert; die Widgets nutzen dieselbe Regel in
  `registerAnchoredPopup()`. Popover nutzt bewusst **keine** Flip-Logik
  (feste Position, siehe §14).
- `registerAnchoredPopup()` — zeigt ein `popover="manual"`-Element in der
  Top-Layer und richtet es mit `position: fixed` am Anker aus: bevorzugte
  Seite (`side`), Wechsel bei zu wenig Platz (`flip`, abschaltbar),
  Ausrichtung `start`/`center`/`end` (`align`, logisch), optional so breit
  wie der Anker (`matchWidth`). Passt es nirgends, wird es in den Viewport
  geschoben, aber nur so weit, dass es am Anker bleibt. Folgt dem Anker bei
  Scrollen und Größenänderung; Cleanup über `DestroyRef`. Genutzt von
  Dropdown, Datepicker, Autocomplete, Popover und Tooltip.
- `registerDismissibleOverlay()` — Escape- und Außenklick-Handling mit
  garantiertem Cleanup über `DestroyRef`. Behebt den in der Spezifikation
  explizit benannten Vanilla-Mangel (kein `destroy()`); vom Wizard bewusst
  mit `closeOnOutsideClick: false` genutzt.

### Bekannte Vereinfachungen gegenüber der Vanilla-Referenz

- Tabellen-Spalten-Resize funktioniert nur mit Maus (kein Touch/Pointer) —
  identisch zur dokumentierten Einschränkung der Vanilla-Referenz.
- `RsTable`s Datums-Filter (`datetime`/`datetime-range`) committen sofort
  bei Auswahl, resetten aber nicht die Kalenderanzeige selbst beim
  Zurücksetzen des Filters über den ×-Button (nur der Filterzustand wird
  geleert).

### Erweiterungen gegenüber der Spezifikation

Funktionen, die über den Vertrag in `widgets-spaceship/specification.md`
hinausgehen. Sie sind optional; ohne sie gilt die Spezifikation.

- **`RsDatepicker` (§16):**
  - Erlaubter Zeitraum über `minDate`/`maxDate`: Tage außerhalb gesperrt,
    Monatsnavigation begrenzt.
  - Tastatursteuerung im Kalender (Pfeiltasten, Pos1/Ende, Bild auf/ab,
    ein Tab-Stopp im Raster) und Rückkehr des Fokus nach Escape und
    Auswahl; gilt für alle Instanzen.
  - Signal Forms: `[formField]` über das zusätzliche Model `value` (mit
    `date` synchron), dazu `disabled`, `invalid` und der Output `touch`.
  - Kalender als Popover in der Top-Layer, im Viewport fixiert: wird von
    keinem Container mit `overflow` abgeschnitten (z. B. Tabellen-
    Filterzeile) und bei zu wenig Platz in den Viewport geschoben; gilt für
    alle Instanzen.
  - Details: [`datepicker.md`](../../documentation/angular%20component%20widgets/datepicker.md).
- **`RsDropdown` (§15) und `RsAutocomplete` (§19):**
  - Menü bzw. Vorschlagsliste als Popover in der Top-Layer, so breit wie
    der Anker, im Viewport fixiert — wie der Kalender des Datepickers;
    gilt für alle Instanzen.
  - Vorschläge des Autocomplete als Block statt Flex, damit die
    `<mark>`-Hervorhebung keine Lücken reißt.
  - Details: [`dropdown.md`](../../documentation/angular%20component%20widgets/dropdown.md),
    [`autocomplete.md`](../../documentation/angular%20component%20widgets/autocomplete.md).
- **`RsPopover` (§14):**
  - Panel als Popover in der Top-Layer, unter dem Trigger, weiterhin ohne
    Wechsel nach oben; Ausrichtung am Ende per `--rs-popover-align: end`
    (App-Bar, Toolbar hinter dem Spacer).
  - Details: [`popover.md`](../../documentation/angular%20component%20widgets/popover.md).
- **Tooltip (§13):**
  - Direktive `RsTooltip` auf `[data-tooltip]`: Text als Popover in der
    Top-Layer, mittig, mit Seitenwechsel und im Viewport; Escape blendet
    aus. Ohne die Direktive bleibt der reine CSS-Tooltip.
  - Details: [`tooltip.md`](../../documentation/css-only%20widgets/tooltip.md#mit-direktive-rstooltip).
- **`RsModal` (§7):**
  - Höchstens `90dvh` hoch, darüber scrollt der Inhalt im Modal.
- **`RsTable` (§21):**
  - `data` als Alternative zu `fetchData` für fertig geladene Listen: kein
    Pager, keine Sortierung/Filter, Höhe nach Inhalt. Genau einer der beiden
    Inputs muss gesetzt sein.
  - Spalten mit `flex` (Breite `minmax(<minWidth>px, <flex>fr)`) und
    `align="end"` (rechtsbündig), Zeilen-Klassen über `rowClass` mit dem
    Modifier `.rs-table__row--muted`, Beschriftung über `label`.
  - Für alle Tabellen: Die Filterzeile erscheint nur, wenn eine Spalte
    einen Filter hat. ARIA-Rollen (`table`, `rowgroup`, `columnheader` mit
    `aria-sort`, `cell`) und beschriftete Filterfelder.
  - Lange Inhalte: Spalten mit `wrap` brechen um, optional begrenzt auf
    `maxLines` Zeilen. Zeilen haben dann eine Mindest- statt einer festen
    Höhe; im Pager-Modus wächst der Körper mit, im Endlos-Modus behält er
    seine feste Höhe. Eigene Zellen nutzen `RsTableText` (`<span
    rsTableText>`) für Ellipse und `title`.
  - Für alle Tabellen: Zu lange Texte der Standardzelle enden mit „…“ statt
    hart abgeschnitten zu werden; der volle Text steht beim Überfahren im
    `title`.
  - Für alle Tabellen behoben: Der Körper wurde beim horizontalen Scrollen
    abgeschnitten, weil er nur so breit wie der sichtbare Bereich war. Er ist
    jetzt so breit wie die Spalten (`--rs-table-min-width`). Der Pager-Footer
    bricht auf schmalen Breiten um. Die Seitengrößen-Auswahl zeigte immer
    die erste Option statt der eingestellten Seitengröße.
  - Details: [`table.md`](../../documentation/angular%20component%20widgets/table.md).
